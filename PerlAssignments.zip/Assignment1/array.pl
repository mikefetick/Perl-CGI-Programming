#!/usr/bin/perl
$\ = "\n";

@sample = (5, 6, 7, 8, 9);
print $sample[0];
print $sample[-1];

@middle = @sample[3-1];
print @middle;

$size = scalar(@middle);
for ($i = 0; $1 < $size; $i++) {
	print $middle[$i];
}
print $separator;

foreach $item (@middle) {
	print $item;
}

print $sample[0];

foreach (@middle) {
	print;
}
@numbers = (1..10);
foreach (@numbers) {
	print;
}

@emptyArray = ();
$loop = 0;
while ($loop < 10) {
	
}