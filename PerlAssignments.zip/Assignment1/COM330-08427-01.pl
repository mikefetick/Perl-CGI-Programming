#!/usr/bin/perl -w 	# C:\Perl64\perl executable can be found with the PATH key in the $ENV hash. Ref 1, pg 119
use 5.010;			# use at least version Perl 5.10 
no warnings;		# can use warnings pragma since Perl 5.6 ref 1, pg 28 (for troubleshooting)
use Cwd;
use File::Spec;
use Win32::Console;				# On Windows, use the Win32::Console module
# use Term::ANSIScreen qw(cls);	# On Unix, you may need to install the module and import the cls function
								# Just use the ActiveState port of Perl's Perl Package Manager (PPM). Ref 1, Pg 191
								# or download Term-ANSIScreen-1.50.tar.gz (31.4 KB) from cspan.org

# 1/8/2015 Michael Fetick, 84270, COM330 Perl CGI Programming, Coleman University
# Ref 1: Learning Perl, 6th Ed, O'Reilly
# perl -v (v5.20.1)

sub menu {
	my $choice;					# my (lexical variable) has private scope. Ref 1, pg 68
	($choice) = @_;				# use Perl's parameter list @_ . Ref 1, pg 67  
	while ($choice ne 'Q') {	# Outer loop while choice is not to Quit. Ref 1, pg 40
 		print "\n";
		print "                MENU\n";
		print "                ----\n";
		print "\n";
		print "        E - Extract and process string\n";
		print "        P - Perform a mathematical operation\n";
		print "        R - Read a directory of files\n";
		print "        F - Find a pattern in a list of files\n";
		print "        L - Determine if a word is a palindrome\n";
		print "        Q - Quit\n";
		print "\n";
		print "       >" . $choice . "\b";	# backspace to overwrite the choice with user editing
		chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
		if ($_ eq '' ) { $_ = $choice; }	# assign default choice to loop last input on Enter Key
		$choice = $_;						# assign new default choice
													# Clear screen before showing menu again
		system $^O eq 'MSWin32' ? 'cls' : 'clear';	# Ref: http://stackoverflow.com/questions/4605593
		print "\n";
		# Warning is displayed one time for this experimental function...
		given ( $_ ) {						# Like C's switch statement. Ref 1, pg 251
			# match, /i case insensitive		# invoke the subroutine for each menu option
			when ( /E/i ) { &option_E(); }	
			when ( /P/i ) { &option_P(); }
			when ( /R/i ) { &option_R(); }
			when ( /F/i ) { &option_F(); }
			when ( /L/i ) { &option_L(); }
			when ( /Q/i ) { exit 0; } 			# Exit to quit, this way
			default { $choice = 'Q'; }			# Quit with anything else
		}
		# exit 0 if $choice =~ /^[Qq]/;				# or exit this way. Ref: http://perldoc.perl.org/functions/exit.html
		# die ", stopped" if $choice =~ /^[Qq]/;	# or die. Ref: http://perldoc.perl.org/functions/die.html
	}
}
sub option_E {
	print "        E - Extract and process string\n\n";
	print "        Enter a string >";
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	print "                        " . $userInput_1 . " has " . length($userInput_1) . " characters.\n";
}
sub option_P {
	print "        P - Perform a mathematical operation\n\n";
	print "        Enter a mathematical expression for PERL to evaluate > "; 
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	my $result = eval($userInput_1);
	print "\n        " . $userInput_1 . " = " . $result . "\n";
}
sub option_R {
	print "        R - Read a directory of files\n\n";
	print "        Enter a directory's name  >";
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	print "\n";
	system $^O eq 'MSWin32' ? 'dir ' . $userInput_1 : 'pwd ' . $userInput_1;
}
sub other_OS {
	# Ref: http://stackoverflow.com/questions/1512729
	local @ARGV = ($fileList);
	chomp(@ARGV);
	print "\nThe pattern '$pattern' was found in these files:\n";

	# Ref: http://www.perlmonks.org/?node_id=597051
	use File::Glob qw( bsd_glob );

	# Inputs
	my @files = @ARGV;
	my $re    = qr/$pattern/;

	my @matches;
	foreach my $file_name (@ARGV) {
		my $matchedFile = "$dirSearch\\$fileList[$file_name]";
		print $matchedFile;
		if (!open(my $fh, '<', "$matchedFile")) {
			warn("Unable to open file \"$file_name\": $!\n");
			next;
		}
		while (<$fh>) {
			if (/$re/) {
			# Save the file name, the line number and the line content.
			push(@matches, [ $file_name, $., $_ ]);
			}
		}
	}
	# Output
	print($_->[0], ',', $_->[1], ': ', $_->[2])
	   foreach @matches;
}
sub option_F {
	print "        F - Find a pattern in a list of files\n\n";

	print "            1.Type the 'directory name'\n";
	print "              or press Enter to search >.\b";
	$dirSearch = <>;	# Call subroutine to trim whitespace from input string, 
	if (trim($dirSearch) eq '' ) { $dirSearch = '.'; }	# assign search of default directory choice
	my $dirSearch = trim($dirSearch);

	if (-d $dirSearch) {
		$abs_path = File::Spec->rel2abs($dirSearch);
		print "-Directory-\n$abs_path\n-Files-\n";
		my ($fileList) = (system $^O eq 'MSWin32' ? 'dir /w/b '. $dirSearch : 'ls -l | more' . $dirSearch);

		print "\n            2.Type the 'pattern' to find\n";
		print "              or press Enter to find >print\b\b\b\b\b";
		$pattern = <>;	# Call subroutine to trim whitespace from input string, 
		if (trim($pattern) eq '' ) { $pattern = "print"; }	# assign search of default pattern choice
		$pattern = trim($pattern);

		if (length($pattern) > 2) {  # Specify a 3-character minimum on the pattern to search
			# For Windows OS use the find function with args for formatting
			system $^O eq 'MSWin32' ? "find /N \"print\" $dirSearch\\*" : &other_OS;
		} else {
		print "\n            The pattern must be at least three characters long!\n";
		}
	} else {
		print "\n            The directory does not exist!\n";
	}

	print "            Press the Enter-Key to continue.. >";
	<STDIN>;	# Call subroutine to trim whitespace from input string, 
}
sub option_L {
	print "        L - Determine if a word is a palindrome\n\n";
	print "        Enter a string >";
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	# Ref: http://stackoverflow.com/questions/15752965
	if ($userInput_1 ne "") {
		my ($word) = $userInput_1;

		my @chars = split //, $word;
		my $palindrome = 1;
		for (0..@chars/2-1) {
			$palindrome = $chars[$_] eq $chars[-($_+1)]
			or last;
		}
		print "                        $word ".($palindrome ? "is" : "isn't")." a palindrome\n";
	}
}
sub trim {	
	# Trim leading and trailing whitespace with regular expression.
    (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    return $s;        
	# Can also be done using the String::Util module's trim method.
	# Perl 6 will include a trim function. 
	# Ref: http://stackoverflow.com/questions/4597937
}
# There is no main routine in Perl
$default = 'F';		# global variable
# Invoke subroutine (user-defined function). Ref 1, pg 63
&menu($default);		# pass the default menu choice 'E' in the subroutine's parameter list
