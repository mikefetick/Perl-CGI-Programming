#!perl 	# C:\Perl64\perl executable can be found with the PATH key in the $ENV hash. Ref 1, pg 119
use 5.010;		# use at least version Perl 5.10 
no warnings;	# can use warnings pragma since Perl 5.6 ref 1, pg 28
use Win32::Console;				# On Windows, use the Win32::Console module
use strict;		# does not allow barewords
#use diagnostics;
use Data::Dumper qw(Dumper);    # qw is a shortcut to make a list. It stands for "quoted words", "quoted by whitespace"
$\ = "\n";
								# Uncomment lines 4 and 34 to clear the screen
# use Term::ANSIScreen qw(cls);	# On Unix, you may need to install the module and import the cls function
								# Just use the ActiveState port of Perl's Perl Package Manager (PPM). Ref 1, Pg 191
								# or download Term-ANSIScreen-1.50.tar.gz (31.4 KB) from cspan.org

# 1/8/2015 Michael Fetick, 84270, COM330 Perl CGI Programming, Chris Olsen, Coleman University
# Ref 1: Learning Perl, 6th Ed, O'Reilly
# perl -v (v5.20.1)

# The word 'my' is a lexical variable that has private scope. In this case it is a Class variable. 
# It is required for variables when using strict. Ref 1, pg 68
my $separator = ("*" x 40);


sub menu_1 {
	# As of Perl 5.002, the built-in $^O indicates which operating system is running.
	# Ref: http://stackoverflow.com/questions/4605593
	no strict;   # briefly, turn off
    os.system("MODE 88,66");  # Ref: http://stackoverflow.com/questions/7552644/resize-cmd-window
	use strict;  # immediately, turn on.
	system $^O eq 'MSWin32' ? 'cls' : 'clear';	# Clear screen before showing menu again
	print "";
	print "                    Perl-Lessons MENU 1";
	print "                    -------------------";
    #                  1st class - 1/7/2015          4th class - 1/28/2015
	print "            1a - Language/History/Setup   4a - DumpNumbers, DumpHash ";
	print "            1b - Perl CGI Programming     4b - Strings, Sort, Reverse ";
	print "            1c - Scalar: '\$' sigil        4c - Map, grep, data-dumping";
	print "            1d - Control Structures       4d - qw (quoted words)";
	print "                                          4e - Regular Expression (RE)";
	#                  2nd class - 1/14/2015 
	print "            2a - Array:  '\@' sigil        4f - Searching with grep";
	print "            2b - Arrays -vs- Lists        4g - Filehandle connection";
	print "            2c - Stacks and Queues        4h - Directory Operations \n";
	#                  3rd class - 1/21/2015         5th class - 2/4/2015
	print "            3a - Hash:   '\%' sigil        5a - ";
	print "            3b - Hash key-value pairs     5b - ";
	print "            3c - Pass Args to Subroutines  \n";
	print "             Q - Quit                      \n";
    print "    ${separator}${separator}";
}


sub menu_2 {
	no strict;   # briefly, turn off
    os.system("MODE 88,65");  # Ref: http://stackoverflow.com/questions/7552644/resize-cmd-window
	use strict;  # immediately, turn on.
	system $^O eq 'MSWin32' ? 'cls' : 'clear';	# Clear screen before showing menu again
	print "";
	print "                    Perl-Lessons MENU 2";
	print "                    -------------------";
    #                  6th class - 2/11/2015         8th class - 2/25/2015
	print "            6a -                          8a - ";
	print "            6b -                          8b - ";
	print "            6c -                          8c - ";
	#                  7th class - 2/18/2015         9th class - 3/4/2015
	print "            7a -                          9a - ";
	print "            7b -                          9b - ";
	print "            7c -                          9c - \n";
	print "             Q - Quit                          \n";
    print "    ${separator}${separator}";
}


sub display_menu_1 {
	my $choice;
	($choice) = @_;				# use Perl's default parameter for a list @_ . Ref 1, pg 67  
	while ($choice ne 'Q') {	# Outer loop while choice is not to Quit. Ref 1, pg 40
		&menu_1;                # Call subroutine to clear the screen and redraw menu_1
		print "    OPTION: " . $choice . "\b\b";	# backspace to overwrite the choice with user editing
		chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
		if ($_ eq '' ) { $_ = $choice; }	# assign default choice to loop last input on Enter Key
		$choice = $_;						# assign new default choice
		# print "\n";
		given ( $_ ) {						# Like C's switch statement. Ref 1, pg 251
			# match, /i case insensitive		# invoke the subroutine for each menu option
			when ( /Q/i ) { exit 0; } 			# Exit to quit, this way
			when ( /m/i ) { my $option = '6a'; &display_menu_2; }	
			when ( /1a/i ) { &menu_1; &option_1a(); my $option = '1b'; } # for the next option (typical)
			when ( /1b/i ) { &menu_1; &option_1b(); my $option = '1c'; }
			when ( /1c/i ) { &option_1c(); my $option = '2a'; }
			when ( /2a/i ) { &option_2a(); my $option = '2b'; }
			when ( /2b/i ) { &option_2b(); my $option = '2c'; }
			when ( /2c/i ) { &option_2c(); my $option = '3a'; }
			when ( /3a/i ) { &option_3a(); my $option = '3b'; }
			when ( /3b/i ) { &option_3b(); my $option = '3c'; }
			when ( /3c/i ) { &option_3c(); my $option = '4a'; }
			when ( /4a/i ) { &option_4a(); my $option = '4b'; }
			when ( /4b/i ) { &option_4b(); my $option = '4c'; }
			when ( /4c/i ) { &option_4c(); my $option = '4d'; }
			when ( /4d/i ) { &option_4d(); my $option = '4e'; }
			when ( /4e/i ) { &option_4e(); my $option = '4f'; }
			when ( /4f/i ) { &option_4f(); my $option = '4g'; }
			when ( /4g/i ) { &option_4g(); my $option = '4h'; }
			when ( /4h/i ) { &option_4h(); my $option = '4i'; }
			when ( /4i/i ) { &option_4i(); my $option = '5a'; }
			default { $choice = 'Q'; }			# Quit with anything else
		}
		# exit 0 if $choice =~ /^[Qq]/;				# or exit this way. Ref: http://perldoc.perl.org/functions/exit.html
		# die ", stopped" if $choice =~ /^[Qq]/;	# or die. Ref: http://perldoc.perl.org/functions/die.html
		no strict;   # briefly, turn off
	    os.system("MODE 88,27");  # Ref: http://stackoverflow.com/questions/7552644/resize-cmd-window
		use strict;  # immediately, turn on.
	}
}


sub display_menu_2 {
	my $choice;
	($choice) = @_;				# use Perl's default parameter for a list @_ . Ref 1, pg 67  
	while ($choice ne 'Q') {	# Outer loop while choice is not to Quit. Ref 1, pg 40
		&menu_1;                # Call subroutine to clear the screen and redraw menu_1
		print "    OPTION: " . $choice . "\b\b";	# backspace to overwrite the choice with user editing
		chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
		if ($_ eq '' ) { $_ = $choice; }	# assign default choice to loop last input on Enter Key
		$choice = $_;						# assign new default choice
		#print "\n";
		given ( $_ ) {						# Like C's switch statement. Ref 1, pg 251
			# match, /i case insensitive		# invoke the subroutine for each menu option
			when ( /Q/i ) { exit 0; } 			# Exit to quit, this way
			when ( /r/i ) { my $option = '1a'; &display_menu_1; }	
			when ( /6a/i ) { &menu_1; &option_1a(); my $option = '6b'; } # for the next option (typical)
			when ( /6b/i ) { &menu_1; &option_1b(); my $option = '6c'; }
			when ( /6c/i ) { &option_1c(); my $option = '7a'; }
			when ( /7a/i ) { &option_2a(); my $option = '7b'; }
			when ( /7b/i ) { &option_2b(); my $option = '7c'; }
			when ( /7c/i ) { &option_2c(); my $option = '8a'; }
			when ( /8a/i ) { &option_3a(); my $option = '8b'; }
			when ( /8b/i ) { &option_3b(); my $option = '8c'; }
			when ( /8c/i ) { &option_3c(); my $option = '9a'; }
			when ( /9a/i ) { &option_4a(); my $option = '9b'; }
			when ( /9b/i ) { &option_4b(); my $option = '9c'; }
			when ( /9c/i ) { &option_4c(); my $option = '6a'; }
			default { $choice = 'Q'; }			# Quit with anything else
		}
		# exit 0 if $choice =~ /^[Qq]/;				# or exit this way. Ref: http://perldoc.perl.org/functions/exit.html
		# die ", stopped" if $choice =~ /^[Qq]/;	# or die. Ref: http://perldoc.perl.org/functions/die.html
		no strict;   # briefly, turn off
	    os.system("MODE 80,27");  # Ref: http://stackoverflow.com/questions/7552644/resize-cmd-window
		use strict;  # immediately, turn on.
	}
}


sub option_1a { 
    print "    OPTION: 1a - Language/History/Setup";
	(my $message = qq{
	Perl is permissive and can be a very eloquent, compact, terse language.
	A backronym, not capitalized; 'Practical Extraction and Report Language' \n
	History: 1987... v5 Overhaul w/ OOP 1991
	  1996-1997 CGI - Common Gateway Interface; uses Perl for dynamic content
	  1998-1999 PHP, Python, ASP, ColdFusion (Better alternatives to CGI)
	  ... 2013 Perldroid, 2014 "Scripting Layer for Android" (SL4A) \n
	Local user group: 'San Diego Perl Mongers' \n
	Unix had built-in tools sed, ack, grep.
	Unix shells (desktop): bash, bourne, aix-korn, csh, tsch.\n
	For Windows, use AciveState.com
	Perl 5.1.16 (Latest), installed the Perl Package Manager (PPM) in C:\\Perl \n
	CPAN - 'Comprehensive Perl Archive Network' is a repository of Perl Modules.\n
	For an IDE, use a text-editor with some intellisense for Perl syntax...
	On Windows, use 'Sublime Text 2' (great for regular expressions)
	   or another free IDE: Eclipse, Notepad++, Komodo Dragon, Padre (advantage)
	Run perl program files with the extension pl, e.g. Assignment1.pl \n
	First, setup and use one of these methods:
	- Method A: type >c:\\Perl\\perl.exe Assignment1.pl
	- Method B: add that path to the variable %PATH% so perl executes anywhere
	- Method C: or use the IDE to build the program. \n
	Perl code is tokenized, lexed/parsed, compiled, and then run.
	Be careful of copy-pasting the apostrophy ' from word processors because
	the code isn't checked at compile-time, it’s checked at run-time.\n
	Build the program in the IDE to see any syntax errors or run the program 
	at the command line, by typing i.e. 'perl -w Perl-Lessons.pl'
	To see even more information about errors, use diagnostics in the program.\n
	The downloaded utility 'Perltidy' can help locate syntax errors; it is a
	tool to indent and reformat perl scripts. Errors are found, fixed, and 
	the program is re-run. If it does not respond, press CTRL-C to stop it.
	}) =~ s/^ {4}//mg;
	print $message;
    print "    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '1b';
        &menu_1;         # Call subroutine to redraw this menu
        &option_1b;      # Call next option
    	}
}


sub option_1b {
    print "    OPTION: 1b - Perl CGI Programming";
	(my $message = qq{
          Documentation about Perl programming can be found at website perldoc.perl.org
            There are tutorials that include: 
              - Perlstyle guide, 
              - Perl Cheat Sheet, 
              - RE Quick, 
              ...\n
          Perl script begins with the following code on the first line: \n
            #!usr/bin/perl  # On Unix, Perl needs this line to know where it is installed,
                            # is the only statement line that is made without a semicolon ;
                            # On Windows this line is a comment and ignored \n
            use strict      # Important: ensures good syntax and does not allow barewords 
                            # It also forces all variables to be explicitly defined within
                            # its scope by proceeding the variable with the word 'my' \n
          Perl treats variables as dynamic data types and automatically converts between
          numbers and strings. It depends on the operator used to determine which data type 
          the variables are. \n
          It is necessary to end all code statements with a semicolon ; \n
          Keyboard input returns a character string, including the newline character '\\n' \n
            It is identified as <STDIN>, or simply as '<>' since <STDIN> is the default. 
            The \\n should be stripped off with:  chomp(<>); \n
            Or if assigned to a variable:  my \$input = <>
            the \\n should be stripped off with:  chomp(\$input);\n
          Perl's favarite default variable: \$_ and can represent the value of <>\n
          Subroutine args can be substituted by a default array variable: \@_ 
          and each subsequent, arg is named by a default scalar variable: \$_[0], \$_[1] ...\n
          Perl's 'foreach' statement iterates through the values of an array \@_ or list \$_ 
	}) =~ s/^ {4}//mg;
	print $message;
    print ("\n") x 3;
    print "    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '1c';
        &menu_1;         # Call subroutine to redraw this menu
        &option_1c;      # Call next option
    	}
}


sub option_1c {
    print "    OPTION: 1c - Scalar: '\$' sigil. The default scalar variable is '\$_'";
	(my $message = qq{
          Perl has scalar values (single value) like numbers, symbols, characters, string. 
          As opposed to an aggregate (plural value), like an array, list, or hash. \n
          Strings can be made within a pair of 'single-quotes' or "double-quotes"
          but the backlash escapes: \\n, \\r, \\t, \\f, \\b, \\\\, \\l, \\L, \\u, \\U  
              are only recognized inside the "double-quoted" strings.\n
          You can make strings span multiple lines with the 'here-document' or use 'qq \{\}' 
          They preserve the whitepace and newline characters. A common practice is to 
          strip the leading whitespace of each line by replacing a pattern (see code).\n
            Boolean values: Perl does not have a dedicated True/False
            - If a value is a number, 0 is False, and everything else is true.
            - If a value is a string, an empty string or '0' is False, 
                          and everything else is true.
	}) =~ s/^ {4}//mg;
	print $message;
	print "      Assign values to variables in various ways: \n";
	print '        (my $fname, my $lname) = ("John", "Smith");';
	(my $fname, my $lname) = ("John", "Smith");
	print '        print "lower case: lc($fname) lc($lname)  upper case: .uc($fname) .uc($lname)';
	print "               lower case: ".lc($fname)." ".lc($lname).'             '.
	"upper case: ".uc($fname)." ".uc($lname);
	my $FNAME = uc($fname);
	my $LNAME = uc($lname);
	print "        print 'The number of characters in \$lname is: '.length \$lname; ".length $lname;
	# print “The number of characters in \$input is: “ . length $input;
	print "\n        substr(\$FNAME,0,1).substr(\$LNAME,0,1): ".substr($FNAME,0,1).substr($LNAME,0,1)."\n";
	print '        (my $average, my $total, my $count) = (0, 0, 0);';
	print "\n        my \$input = <>;";
	print "        chomp(\$input); \n";
	print "        my \$line = \"<tr style='.'%s'.'><td>Row</td><td></td></tr>\";";
	my $line = "<tr style='%s'><td>Row</td><td></td></tr>";
	print '        printf "        $line", ' . "'bold';";
	printf "      $line\n\n", 'bold';
	print '         printf("     %d + %d = %d\n", 5, 5, 5 + 5);';
	print '         my $my_sprintf = sprintf("%d + %d = %d\n", 7, 7, 7 + 7);';
	print '         print $my_sprintf;';
	my $my_sprintf = sprintf("%d + %d = %d", 7, 7, 7 + 7);
	$\ = "";
	printf("      %d + %d = %d", 5, 5, 5 + 5);
	print "    #  printf is good\n";
	print "      $my_sprintf";
	print "    # sprintf is better - the result can be assign to a variable. \n";
	$\ = "\n";
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '1d';
        &menu_1;         # Call subroutine to redraw this menu
        &option_1d;      # Call next option
    	}
}


sub option_1d {
    print "    OPTION: 1d - Control Structures ";
	(my $message = qq{
          Conditional blocks (Ref 1, page 37): if, unless, while 
            Perl does not have a switch statement but it does have an elsif (lacks e)\n
            if (\$input < 0) {                         # ...test for minimum...
                print "0 - It's below the range.";    #     ...do something...
            } elsif (\$input > 0 && \$input <= 25) {    # ...test for pass...
                print "1 - It's within the range.";   #     ...do something else...
            } else {                                  # ...test for maximum...
                print "0 - It's above the range.";    #     ...do something else...
            }
            unless (\$input > 0 && \$input <= 25) {     # ...test for fail...
                print "0 - It's not within the range.";   # ...do something...
            } 
            Conditional Ternary Operator ?:  expression ? if_true_expr : if_false_expr \n
          Loop blocks (Ref 1, page 179): for, foreach, while, until, naked block\n
            for (initialization, test, increment) {
                ...loop that runs for a certain count of times...
            }
            foreach (an array \@_ or a list \$_) {
                ...iterate in a loop foreach item in the collection \$_[i]...
                redo ...redo the current iteration, jump to the top...
                next ...done with current iteration, jump to the bottom...
                last ...immediately ends execution of the loop, jump out...
            }
            while (test) {
                 ...loop that runs at least once...
            }
            until (test) {...}\n
            {...naked block...}\n
          Test strings with: = gt ge lt le eq ne   Concatenate strings with: . 
          Test numbers with: = >  >= <  <= == != \n
          Code blocks (if, while, for) require an opening brace '{' on the same line
              # indent code four spaces (no tabs) on the next line, 
          '}' # then the closing brace on the next line.
	}) =~ s/^ {4}//mg;
	print $message;
    print "    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '2a';
        &menu_1;         # Call subroutine to redraw this menu
        &option_2a;      # Call next option
    	}
}


sub option_2a {
    print "    OPTION: 2a - Array: '\@' sigil. The default array variable is '\@_'";
	my $message = qq{
    Perl has an aggregate value (plural value) like an array, list, or hash.
    As opposed to a scalar (singular value), like a number, symbol, character, string. 
	};
	print $message;
	my @simple = (7, 8, 9);
	print "        my \@simple = (7, 8, 9);";
	print '        print "Variable @simple - resolved in double-quoted text;'."\"";
	print "               Variable @simple - resolved in double-quoted text\n";
	print "    Arrays \@_ contain \$elements \$_. They print without whitespace or a new line \n";
	print '        print @simple;          # no whitespace unless concatenated with a string:';
	$\ = "";
	print "    ";
	print @simple;
	print "\n        print \@simple[0..1];    @simple[0..1]  # - a range of elements is specified. \n";
	print "    ";
	print @simple[0..1];
	$\ = "\n";
	print "  print \@simple[0];       @simple[0]    # - a single element is specified.";
	print "        print \"\$simple[0];\"     $simple[0]    # - it's better written with the \$";
	print "        print \$simple[0];       $simple[0]    # - it's best to leave out the quotes\n";
	my @my_array = (5, 6, 7, 8, 9, 10, 11, 12, 13);
	print '        my @my_array = (5, 6, 7, 8, 9, 10, 11, 12, 13);';
	print '        $my_array[0];   results '.$my_array[0].'   # the first item';
	print '        $my_array[-1];  results '.$my_array[-1].'  # the last item';
    # next topic
	print "";
	my @newSample = splice @my_array, 1, 4;
	print '        my @newSample = splice @my_array, 1, 4;    # array, offset, length';
	print '        print "\@newSample: " . scalar(@newSample);   result:  '.scalar(@newSample);
	print '      print for @newSample;';
	print for @newSample;
    # next topic
	print "        my \@emptyArray = ();";
	my @emptyArray = ();
	print '        push @emptyArray, $_ for (1..15);    # - pushes 15 items into the array';
	push @emptyArray, $_ for (1..15); 
	print '        foreach (@emptyArray) {       ';
	print '            print;                           # - implicitly prints each item, ';
	print '        }                                          (notice no whitespace) ';
	#print '        print "After, the array contains:  \@emptyArray"';
	print '        print @emptyArray                    #   (notice whitespace)';
	$\ = "";
	print "      Result: ";
	foreach (@emptyArray) {
		print;
	}
	$\ = "\n";
	print "\n              @emptyArray \n";
    # next topic
	my @words = ("Oh", "say", "can", "you");
	print "    The \$# returns the index of the last item ";
	print '        my @words = ("Oh", "say", "can", "you");';
	print "      $#words is the index of the last word in the array, determined by \$#words. ";
	print "      ".scalar(@words)." is the count of all the words in the array, determined by scalar(\@words).\n";
    print "    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '2b';
        &menu_1;         # Call subroutine to redraw this menu
        &option_2b;      # Call next option
    	}
}


sub option_2b {
    print "    OPTION: 2b - Arrays -vs- Lists";
	(my $message = qq{
        A list is the data and the array is the variable that stores that data.
          1. An array is a variable but a list is not.
          2. Arrays content can be changed but a list's contents cannot.
          3. Arrays can have names but a list cannot.
          4. Arrays can have sigels but a list may not.
          5. Arrays can be referenced but a list cannot be.
          6. Arrays use parentheses to create elements but list use brackets 
          7. Arrays use brackets to access the elements 
	}) =~ s/^ {4}//mg;
	print $message;
    print "    ${separator}${separator}";
    # next topic
	print '        my @words = ("Oh", "say", "can", "you");';
	print '        my $refToArray = \@words;'."               # the '\\' is not escaping the @ symbol";
	print '        print $refToArray;';
	my @words = ("Oh", "say", "can", "you");
	my $refToArray = \@words; 
	print '      '.$refToArray.'    # to reference the array';
    # next topic
    print "";
	print '      use Data::Dumper qw(Dumper);  # to get data dumped ';
	print "      print Dumper \\\@words;         # from a referenced address";
	print Dumper \@words;
    # next topic
	print "      qw returns an array of tokens";
	print '        my @moreWords = qw(Today is Wednesday January 14, 2015);';
	print '        print "$_" for @moreWords;';
	my @moreWords = qw(Today is Wednesday January 14, 2015);
	print "      $_" for @moreWords;
    # next topic
	print "\n      With qw use parentheses and multiple operators.";
	@moreWords = qw('"San Diego" Today is January 14, 2015 $data');
	print '      Use \\ forward slash operator to get references to each word.';
	print "        \@moreWords = \\qw('\"San Diego\" Today is January 14, 2015 \$data');";
	@moreWords = \qw('"San Diego" Today is Wednesday January 14, 2015 $data');
	print "      @moreWords";
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
	print "      ";
    } elsif ($option ne 'm') {
        $option = '2c';
        &menu_1;         # Call subroutine to redraw this menu
        &option_2c;      # Call next option
    	}
} 


sub option_2c {
    print "    OPTION: 2c - Stacks and Queues\n";
	print "     'Stacks' are good for traversing all the paths of a binary tree.";
	print "      Items are added/removed from the right side of a list.";
	print "      The 'push' action adds item 5 of (1, 2, 3, 4). ";
	print "      The 'pop' action removes item 5 of (1, 2, 3, 4, 5).";
	print '        my @array = (1, 2, 3);                           # - create array of 3 items ';
	my @array = (1, 2, 3);
	print '        push @array, $_ for 4..8;                        # - push 5 more into @array ';
	push @array, $_ for 4..8;
	print "     'Queues' are good for keeping order in a buffer, when handling bottlenecks.";
	print "      Items are added to the left / removed from the right sides of a list.";
	print "      The 'unshift' action adds item 5 of (1, 2, 3, 4).";
	print "      The 'shift' action removes item 1 of (1, 2, 3, 4, 5). \n";
	print '        # - shift out each item and print the item you get - while @array is not empty:';
	print '        printf "val %d  ", shift @array while @array;';
	print "      Result:   ";
	printf "%d. %d  ", @array[$#], shift @array while @array;
	$\ = "\n";
	print "\n";
    # next topic
	print "        \@array = ('Larry', 'Curly', 'Moe');";
	my @stooges = ('Larry', 'Curly', 'Moe');
	print "        # print each item of \@stooges by implicitly using the default '\$_'";
	print '        print "@stooges";';
	$\ = "";
	print "      Result: ";
	print "@stooges\n\n";
	# Restore @array for the next operation
	# unshift(@array, 'Moe'); unshift(@array, 'Curly'); unshift(@array, 'Larry');
	$\ = "\n";
    # next topic
	print '        my $size = scalar(@stooges);';
	print '        while ($size > 0) {';
	print '            $size = scalar(@stooges);';
	print '            printf "size:%{d}, %s \n", $size @stooges;';
	print '            shift @stooges;';
	print '        }';
	$\ = "";
	my $size = scalar(@stooges);
	while ($size > 0) {
		$size = scalar(@stooges);
		printf("     size: %s , %s \n", $size, @stooges);
		shift @stooges;
	}
	$\ = "\n";
	# Create a queue
	print "\n    Queue - 'unshift' in this order: ";
	print "      unshift(\@stooges, 'Moe'); unshift(\@stooges, 'Curly'); unshift(\@stooges, 'Larry');";
	unshift(@stooges, 'Moe'); unshift(@stooges, 'Curly'); unshift(@stooges, 'Larry');
	print "    Result: The three stooges are: ".join(", ", @stooges)."\n";
	# Create a stack
	print "    Stack - 'unshift' in this order: ";
	shift(@stooges); shift(@stooges); shift(@stooges);
	print "      unshift\(\@array, 'Larry'); unshift(\@stooges, 'Curly'); unshift(\@stooges, 'Moe');";
	unshift(@stooges, 'Larry'); unshift(@stooges, 'Curly'); unshift(@stooges, 'Moe');
	print "    Result: The three stooges are: ".join(", ", @stooges)."\n";
    print "    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '3a';
        &menu_1;         # Call subroutine to redraw this menu
        &option_3a;      # Call next option
    	}
}


sub HandleHash {
	print " ";
}


sub option_3a {
    print "    OPTION: 3a - Hash: '\%' sigil. The default hash variable is '\%_'";
	(my $message = qq{
        Hash is like an array but instead of indexing by number, you look up hash values 
        by name, called keys. Each key must be unique, paired with a 'value' accessed by 
        the key. If you want to inverse the hash, assign with the 'reverse' keyword but 
        only if all the values are unique, to be a key. When assigning a list to a hash, 
        it can be confusing to tell which is the keys and which is the values. This can
        be simplified with the big arrow '=>' instead of commas, called the 'fat comma.'
	}) =~ s/^ {4}//mg;
	print $message;
	print "    Create a hash with parentheses of key-value pairs, assigned to a hash variable:";
	print '      my %areaCodes = ("619", "San Diego", "714", "Orange County", "707", "San Rosa");';
	my %areaCodes = ('619', 'San Diego', '714', 'Orange County', '707', 'San Rosa');

	print "\n    Use the 'each' function, in a while \%areaCodes exists loop, to assign each";
	print "    successive key-value pair to variables (Note the use of = and not == )\n";
	print '      while ( (my $key = keys, my $value = values) = each %areaCodes ) {';
	print '          print $key . " => " . $value;';
	print '      }';
	while ( (my $key, my $value) = each %areaCodes ) {
		print("$key => $value");
	}
	my $count = keys %areaCodes;
	print "      my \$count = keys \%areaCodes;  result: $count";
    # next topic
	print "\n    The fat-comma does the same thing but the hash probably won't be in the same order\n";
	print '      %areaCodes = ("619" => "San Diego", "714" => "Orange County", "707" => "San Rosa")';
	%areaCodes = ("619" => "San Diego", "714" => "Orange County", "707" => "San Rosa");

	print '      while ( (my $key, my $value) = each %areaCodes ) {';
	print '          print $key . " => " . $value;';
	while ( (my $key, my $value) = each %areaCodes ) {
		print($key . " => " . $value);
	}
	$count = keys %areaCodes;
	print "      \$count = keys \%areaCodes;  \n    result: $count \n";
    # next topic
	print "    Converting a hash into a list is called unwinding the hash:\n";
	my @anyArray = %areaCodes;
	print "      my \@anyArray = \%areaCodes  \n    result: @anyArray";
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '3b';
        &menu_1;         # Call subroutine to redraw this menu
        &option_3b;      # Call next option
    	}
}


sub Multiply
{
	my $first = $_[0];
	my $second = $_[1];

	# print "Undefined..." if undef($second)
	return $first * $second;
}


sub Multiply2
{
	my $first = shift;
	my $second = shift;

	return $first * $second;
}


sub Multiply3
{
	my ($first, $second) = @_;
	return $first * $second;
}


sub Multiply4
{
	(my $first, my $second) = @_;
	$first * $second;
}


sub option_3b {
    print "    OPTION: 3b - Hash key-value pairs";
	(my $message = qq{
        A hash can be iterated through with the 'each' or 'foreach' functions, or by the  
        list of keys. It's best to check if a key exist before trying to get its value.
	}) =~ s/^ {4}//mg;
	print $message;
    # next topic
	my %areaCodes = ("619" => "San Diego", "714" => "Orange County", "707" => "San Rosa");
	print "    Print hash:";
	print '      my %areaCodes = ("619"=>"San Diego", "714"=>"Orange County", "707"=>"San Rosa");';
	print '      while ( (my $key = keys, my $value = values) = each %areaCodes ) {';
	print '          print $key . " => " . $value;';
	print '      }';
	while ((my $key, my $value) = each(%areaCodes)) {
		print $key . " => " . $value;
	}

	print "\n    Print the values of the hash by #1:";
	my %data = %areaCodes;
	print "      my \%data = \%areaCodes;";
	print "      for my \$ac (keys \%data) {";
	print "      	print \$data{\$ac};";
	print "      }";
	for my $ac (keys %data) {
		print $data{$ac};
	}

	print "\n    Print the values of the hash by #2:";
	print "      foreach my \$k (keys \%data) {";
	print "      	print \$data{\$k};";
	print "      }";
	foreach my $k (keys %data) {
		print $data{$k};
	}

	print "\n    Print the keys of the hash:";
	print "      my \@names = keys \%data;";
	print "      foreach (\@names) {print}";
	my @names = keys %data;
	foreach (@names) {print}

	# Checking to see if the key exists
	print "      if (exists(\$data{'619'})) {";
	if (exists($data{'619'})) {
		print "        Checking to see if the key exists:   619 is $data{'619'}";
	} else {
		print "        Checking to see if the key exists:   619 is not in the hash.";
	}

	# Checking to see how many items are
	print "      if (exists(\$data{'619'})) {";
	if (exists($data{'619'})) {
		print "        Checking to see how many items are:  ".keys %data;
	} else {
		print "        Checking for how many items there are:  619 is not in the hash.";
	}
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '3c';
        &menu_1;         # Call subroutine to redraw this menu
        &option_3c;      # Call next option
    	}
}


sub HandleArrays
{
	#my @myNumbers = shift;
	#print '    my @myNumbers = @{$_[0]};';
	#print '    Result: Can\'t use string ("5") as an ARRAY ref while "strict refs"';
	#my @myNumbers =  @_   # Result: error
	# @myNumbers = {shift};   # Do not use this!
	# my @myNumbers = @{$_[0]};
	# my @myNumbers = @{$_}; Result: error (same as @{$_[0]})
	#say $_[1];  
	print "        say \@_ is @_;            # ...in the sub HandleArrays";
	say @_;  

	#print $saying;
	# foreach my $item(@myNumbers) {  # Result: error
	#foreach my $item(@_) {  # Result: error
	#	print $item;
	#}
}


sub option_3c {
    print "    OPTION: 3c - Pass Args to Subroutines";
	(my $message = qq{
        Subroutines can be called with the '\&' prefix and the returned value can be used 
        in a local expression. Inside the subroutines, passed arguments are recognized 
        by either the parameter's index number in brackets, by shifting the arguments 
        into the default input, or by thier own default sigil type, i.e. \$_, \@_, \%_.
	}) =~ s/^ {4}//mg;
	print $message;
	print "    Return the result of a subroutine call; see the code in the subroutines";
	print '        &Multiply(11); results '.&Multiply(11).' and     &Multiply2(11, 15); results '.&Multiply2(11, 15);
	print "\n    Split a string on delimiter : and it's best to position string-type fields first.";
	print "      Format of Input File: first_name : last_name : student_ID : mod_no : start_date \n";
	print '        (my $first_name, my $last_name, my $student_ID, my $mod_no, my $start_date) = ';
	print '            split /:/, $input_line;    # Assign multiple variables to the results';
	print '        my $output_line =  sprintf("%s %s - %s in Mod %d on %s", ';
	print '            $first_name, $last_name, $student_ID, $mod_no, $start_date);';
	my $input_line  = "Joe:Smith:50432:1:03-16-2014";
	(my $first_name, my $last_name, my $student_ID, my $mod_no, my $start_date) = split /:/, $input_line; # multiple variables
	my $output_line =  sprintf("      %s %s - %s in Mod %d on %s", $first_name, $last_name, $student_ID, $mod_no, $start_date);
	print "\n      Result: (The first input line was 'Joe:Smith:50432:1:03-16-2014)'";	
	print $output_line;
    # next topic
 	print "\n        my \@numbers = (5, 6, 7);";
	print "        \&HandleArrays(\@numbers);    # You can pass arrays or a list to subroutines.";
	my @numbers = (5, 6, 7);
	&HandleArrays(@numbers);
    # next topic
	#print "    Transliteration Operator '~'";
	#print '        my $data = "lowercase data";';
	#print '        print "uc($data);"';
	#my $data = "lowercase data";
	#print "        ".uc($data);

	#print '        my $newdata = $data =~ tr/a-z/A-Z/;';
	#print '        print $newdata;';
	#my $newdata = $data =~ tr/a-z/A-Z/;
	#print $newdata;

	#print '        my $string = $data =~ tr/abcdefghij/012345789/;';
	#my $string = $data =~ tr/abcdefghij/012345789/;
	#print '        print $string;   result: '.$string;
	
	print '        my $expr = "This is a test";';
	my $expr = "This is a test";
	print "        print index \$expr, 'is';    result: ".index $expr, 'is';    # '2'
	print "        print substr \$expr, 5;      result: ".substr $expr, 5;       # 'is a test.''
	print "        print substr \$expr, 5, 7;   result: ".substr $expr, 5, 7;   # 'is a te'

	my $newINPUT = "THIS IS A TEST";
	print "        print 'Eureka!' if ($expr =~ /is/gi);    result: ".'Eureka!' if ($expr =~ /is/gi);
	print '';
	$expr =~ tr/iat/943/;
	print '        $expr =~ tr/iat/943/;  # inline transliteration';
	print '      result: '.$expr."\n";
	print '        $_ = "this is a string";';
	$_ = "this is a string";
	print '      s/ /_/g;           # replaces all the spaces with the underscore, globally';
	s/ /_/g;
	print '      print;  '.$_;

	#my $newInput =~ tr/is/wz/;
	#print $newInput;

	#print "Start entering some data: ";
	#while (<>) {
	#	tr/a-z/A-Z/;  # the tr is the transliteration operator
	#	print;
	#}
    print "\n" x 4;
    print "    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '4a';
        &menu_1;         # Call subroutine to redraw this menu
        &option_4a;      # Call next option
    	}
}


sub DumpNumbers {
	print '    sub DumpNumbers {';
	#my @myNumbers = @{$_[0]};    
	print '        my @myNumbers = @{shift @_};';
	my @myNumbers = @{shift @_};
	#1st parameter = delimiter, will be used as a scalar(@list) - 1
	print '        print join ", ", @myNumbers;';
	print join ", ", @myNumbers;
}


sub DumpContainer {
	my @myNumbers = @{shift @_}; 	# my @myNumbers = @{shift @_};
	my %myHash = %{shift @_};
	print "";
	print join ", ", @myNumbers;
	print join "";
	foreach my $item (keys my %myHash) {
		print $item . " = " . $myHash{$item};
	}
}


sub DumpNumbers2 {
	print '    sub DumpNumbers2 {';
	my @myNumbers = @{shift @_};
	print join ", ", @myNumbers;
	print join "\n" . ("-" x 50);
}


sub DumpHash {
	print '    sub DumpHash {';
	print '        my @myHash = @{shift @_};';
	my %myHash = @{shift @_};
	#my $value = %myHash{$item};
	#my %myHash = @_[0];
	print '        foreach my $item (keys %myHash) {';
	print '            print $item . " = " . $myHash{value} . "\n";';
	print '        }';
	foreach my $item (sort keys %myHash) {
		print $item . " = " . %myHash{$item};
	}
}


# Build constructs and return them to the caller
sub ObjectBuilder {
	# Preface my variables with my
	my $scalarValue = "test data";
	my @myArray = ( 20..25 );
	my %myHash = ( "KNBC" => "Los Angeles", "KGTV" => "San Deigo",
					"KGO" => "San Francisco", "KFMB" => "San Diego");
	return (\@myArray, \%myHash, $scalarValue);   # The '\' means you are passing the reference
}

#DumpContainer(my \@number, my \%zipCodes);

sub option_4a {
    print "    OPTION: 4a - DumpNumbers, DumpHash ";
	(my $message = qq{
          my \@number = (1..5);
          my \%zipCodes = ("92111" => "Kerney Mesa",    "92109" => "Pacific Beach",
              "92108" => "Mission Valley", "91941" => "La Mesa",
              "92126" => "Mira Mesa",      "92101" => "Downtown");
	}) =~ s/^ {4}//mg;
	print $message;
	my $single = 1;
	my @number = (1..5);
	my %zipCodes = ("92111" => "Kerney Mesa",    "92109" => "Pacific Beach",
			        "92108" => "Mission Valley", "91941" => "La Mesa",
			        "92126" => "Mira Mesa",      "92101" => "Downtown");
	DumpNumbers(\@number);
	#DumpNumbers(\@number);
	#DumpNumbers2(\@number);
    print "";
	DumpHash(\@number);
	# @_ is the first item in the array
	# shift
	# list assignment. Use @{$_[0]} to force it to be a list.
	# pass 1st string parameter, the 2nd param is the list

    print "\n" x 18;
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '4b';
        &menu_1;         # Call subroutine to redraw this menu
        &option_4b;      # Call next option
    	}
}


sub option_4b {
    print "    OPTION: 4b - Strings, Sort, Reverse \n";
	print "      Perl has separate operators when comparing numbers than comparing strings. \n";
	print "      Numbers are sorted with the numeric comparison <=> operator, also called ";
	print "      the spacehip operator (from Star Wars). \n";
	print "        my \@not_sorted = (303, 5, 209, 777, 51, 38);";
	my @not_sorted = (303, 5, 209, 777, 51, 38);
	print "        my \@sorted = sort { \$a <=> \$b } \@not_sorted; \n"; 
	my @sorted = sort { $a <=> $b } @not_sorted;  # 
	print "        The \@sorted result: @sorted\n";
	print '        my $val1 = 55;';
	print '        my $val2 = 66;';
	print '        if ($val1 > $val2) {';
	my $val1 = 55;
	my $val2 = 66;
	if ($val1 > $val2) {
		print "\n            True \n";   # // True or 1 
	} else {
		print "\n            False \n";   # // False 
	}
    # next topic
	print "      Alpha-numeric chracters (letters) are sorted with the string ";
	print "      cmp operator: \n";
	my @strings = qw / this school is located on balboa ave/;
	print "        my \@strings = qw / this school is located on balboa ave/;";
	my @sorted_strings = sort { $a cmp $b } @strings; 
	# strcmp returns -1, 0, 1, so "abc" > "ABC", (97, 98, 99) > (65, 66, 67) (colation sequence)
	print "        my \@sorted_strings = sort { \$a cmp \$b } \@strings;";
	print "\n      Sorted a-z: @sorted_strings \n";
    # next topic
	#print '        my @reverse = sort { $b cmp $a } qw /the rain in spain falls on the plain/;';
	my @reverse = sort { $b cmp $a } qw /the rain in spain falls on the plain/;
	#print @reverse;
	print "        my \@reverse = sort { \$b cmp \$a } qw /the rain in spain falls on the plain/;";
	print "\n      Sorted z-a: @reverse; \n";
    # next topic
	print "      An 'out of place' sort is usually done in a subroutine. \n";
	print '        my $str1 = "xyz"';
	print '        my $str2 = "XYZ"';
	print '        if ($str1 lt $str2) {';
	my $str1 = "xyz";
	my $str2 = "XYZ";
	if ($str1 lt $str2) {
		print "\n            True";   # // True or 1 
	} else {
		print "\n            False";   # // False 
	}
    print "\n" x 3;
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '4c';
        &menu_1;         # Call subroutine to redraw this menu
        &option_4c;      # Call next option
    	}
}


sub Square {
	my $number = shift;
	return $number * $number;
}


sub option_4c {
    print "    OPTION: 4c - Map, grep, data-dumping ";
	(my $message = qq{
          Create a list using a line syntax with a range of numbers.
	}) =~ s/^ {4}//mg;
	print $message;
	print '        my @numbers = (1..10);';
	my @numbers = (1..10);
	print "        print \@numbers;          result:  @numbers \n";
	#my @squareNumbers = 0;
	#foreach my $number (@numbers) {
	#	push(@squareNumbers, Square(my $numbers));
	#}
	#print @squareNumbers;
    # next topic
	my @mappedNumbers = map { $_ * $_ } @numbers;
	print "        my \@mappedNumbers = map { \$_ * \$_ } \@numbers;";
	print "        print \@mappedNumbers;    result:  @mappedNumbers \n";
    # next topic
	print "        \@mappedNumbers = map { Square(\$_) } \@numbers;";
	@mappedNumbers = map { Square($_) } @numbers;
	print "        print \@mappedNumbers;    result:  @mappedNumbers \n";
    print "\n" x 27;
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '4d';
        &menu_1;         # Call subroutine to redraw this menu
        &option_4d;      # Call next option
    	}
}


sub option_4d {
    print "    OPTION: 4d - qw (quoted words) ";
	(my $message = qq{
          Another example to use the map to load up the contents of a hash
          Handy when you want to initialize all the values of a hash.
          The map function is most useful; it transforms a collection to a hash.
          We can do more than one line. We can change the contents of an array.
	}) =~ s/^ {4}//mg;
	print $message;
	print "        my \@names = qw /thomas brian steven james/;";
	my @names = qw /thomas brian steven james/;
	print "        my \%is_invited = map { \$_ => 1..4} \@names;";
	my %is_invited = map { $_ => 1..4} @names;
	print "\n      Iterating through the hash";
	print "        while ((my \$keys, my \$value) = each(\%is_invited)) {";
	print '            print "$keys: $value";';
	print "        } ";
	while ((my $keys, my $value) = each(%is_invited)) {
		print "$keys: $value";
	}
	#print "      Enter a name: ";
	#my $visitor = <STDIN>;
	#$visitor = chomp($visitor);
	#if ($is_invited{$visitor}) {
	#	print "The visitor $visitor is here";
	#}
    # next topic
	my @middleNames = qw /sammy larry bobby jimmy/;
	my @newMiddleNames = map { ucfirst } @middleNames;
	print "        my \@middleNames = qw /sammy larry bobby jimmy/;";
	print "        my \@newMiddleNames = map { ucfirst } \@middleNames;";
	print "        print \@newMiddleNames;";
	print "@newMiddleNames\n";

	print "        my \@firstNames = qw /joe steven robert larry freddie/;";
	my @firstNames = qw /joe steven robert larry freddie/;

	print "        my \@everyone = map {";
	print "            uc,";
	print "            \$_, ucfirst . \"'s car\"";
	print "        } \@firstNames;";
	my @everyone = map {
		uc,
		$_, ucfirst . "'s car"
	} @firstNames;
	print "        print \"@everyone\";";
	print "@everyone\n";

	print "      # Create a hash";
	print "      my %nameHash = (\"thomas\" => 1,";
	print '          "james"  => 2,';
	print '          "steven" => 3,';
	print '          "brian"  => 4);';
	my %nameHash = ("thomas" => 1,
					"james" => 2,
					"steven" => 3,
					"brian" => 4);
	print %nameHash;
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '4e';
        &menu_1;         # Call subroutine to redraw this menu
        &option_4e;      # Call next option
    	}
}


sub option_4e {
    print "    OPTION: 4e - Regular Expression (RE) ";
	(my $message = qq{
          Regular Expression (RE)
	}) =~ s/^ {4}//mg;
	print $message;
	my $sentence = "I would like to go to london this year";
	print "        \$sentence before: $sentence \n";
	print "        \$sentence =~ s/London/London/;\n";
	$sentence =~ s/London/London/;
	print "        \$sentence after: $sentence";
    # next topic
    print "\n" x 31;
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '4f';
        &menu_1;         # Call subroutine to redraw this menu
        &option_4f;      # Call next option
    	}
}


sub option_4f {
    print "    OPTION: 4f - Searching with grep ";
	(my $message = qq{
          Perl searches text (strings) using grep utility to search for a pattern. 
          Grep is typically useful to filter out words less than eight characters. \n
          Use back slashes / / for string comparisons. 
	}) =~ s/^ {4}//mg;
	print $message;
	print '        my @h_array = (1, "Test", 5.5, "foo", -65, 20);';
	print '        my @has_digits = grep /-?\d+(\.\d+)/, @h_array;  # (1, 55, 65, 20)';
	print '        print join ", ", @has_digits;';
	my @h_array = (1, "Test", 5.5, "foo", -65, 20);
	print "\n      The RE can be built with the search/replace feature of Sublime and we begin";
	print "      match - multiple digits with:         \d+ ";
	print "      match - numbers with a decimal point: \d+\.\d+";
	print "      and make it optional with:            \d+(\.\d+)?";
	print "      and add optional negative numbers:    -?\d+(\.\d+)? \n";
	print '        my @has_digits = grep /-?\d+(\.\d+)?/, @h_array;';
	print '        print join ", ", @has_digits;';
	my @has_digits = grep /-?\d+(\.\d+)?/, @h_array;
	print join ", ", @has_digits;
	print "";
    # next topic
	print '        my @products = qw /potatoes lemons apricots apples banannas pineapple/;';
	my @products = qw /potatoes lemons apricots apples banannas pineapple/;
	print '        print @products;';
	print @products;
    # next topic
	print "\n      Find words that match many different ways.";
	print "      Use braces {} when doing a call to a built-in function, i.e. length, count.";
	print "      For example - words shorter than eight characters: \n";
	print "        my \@small_words = grep { length \$_ < 8 } \@products;";
	print '        for my $index (@small_words) {';
	print '            print $index;';
	print '        }';
	my @small_words = grep { length $_ < 8 } @products;
	for my $index (@small_words) {
		print $index;
	}
    print "\n" x 6;
    print "    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '4g';
        &menu_1;         # Call subroutine to redraw this menu
        &option_4g;      # Call next option
    	}
}


sub option_4g {
    print "    OPTION: 4g - Filehandle connection, to request the OS to read a file";
	(my $message = qq{
          Perl uses a filehandle connection to read a file. Early filehandles used bare 
          words and some special ones still do; it's suggested to use UPPERCASE names,
          e.g. sample filehandle names: CONFIG, LOG, 
          Perl already uses: STDIN, STDOUT, SRDERR, DATA, ARGV, and ARGVOUT. 
          Standard input streams and standard output streams can be chained together
          with the '|' symbol, called a pipe and used extensively in Unix. \n 
          We use the 'open', 'readline', and 'close' functions.
          Use a 'three-argument' open, to '\<' input, '\>' output, and append '\>\>' data:
              open CONFIG, '<', 'dino'
              open BEDROCK, '>', \$file_name;
              open LOG, ''>>:encoding(UTF-8)', &logfile_name();  # can specify encoding\n
          Lists all encodings: % perl -MEncode -le "print for Encode->encodings(':all')" \n
          And handle fatal errors with 'die' or use 'warn' to let exit the program. \n
          Since, Perl 5.6 a filehandle reference is stored in a scalar variable.
          This makes it easier to pass a filehandle as a subroutine argument, 
          store them in arrays or hashes, or control its scope. \n 
          You can name the variable with '_fh' as a reminder it's a filehandle:
             open my \$rocks_fh, '<', 'rocks.txt' or die "Could not open rocks.txt: \$!" \n
          This works for output files too:
             foreach my \$rock ( qw( slate lava granite ) ) {
                 say \$rocks_fh \$rock
             }
             print \$rocks_fh "limestone\\n"    # notice no comma after the filehandle
             close \$rocks_fh; \n
          Filehandles can also be referenced inside angle brackets like \<\$rocks_fh>.
	}) =~ s/^ {4}//mg;
	print $message;
    print "\n" x 4;
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '4h';
        &menu_1;         # Call subroutine to redraw this menu
        &option_4h;      # Call next option
    	}
}


sub option_4h {
    print "    OPTION: 4h - Directory Operations";
	(my $message = qq{
          Globbing - When the shell expands text patterns into matching filenames.
          For example, glob '*'; expands into a sorted list of the filenames of all files 
          but excludes the . (current directory) and the .. (parent directory). 
          To include files starting with dot, we add: \n
            my \@all_files_including_dot = glob '.* *'\n 
          An alternative syntax for globbing is the <*> glob operator:
            my \@all_files = <*>;\n 
          Globbing can also be referenced (with the *) inside angle brackets like this:
            my \@files = <\$name/*>;    # a glob 
            my \@files = <\$name>;      # a filehandle read, not a glob\n\n 
          Directory Handle - Perl has the bareword DIR connection and like a filehandle, 
          it's better to assign the directory handle to a scalar variable.
          We use the 'opendir', 'readdir', and 'closedir' functions.
          Unfortunately, it returns a list of filenames unsorted and includes the . and
          .. directories. We can fix that by using a skip-over function inside a loop. 
          We form an RE to match the filenames we want, e.g. to match all non-dot files: \n
            while (\$name = readdir \$dh) {
                next unless \$name =~ /^\\./;
            	... more processing ...
            }
          We can change the match to include filenames that start with a dot 
          but excludes the . (current directory) and .. (parent directory): \n 
                next if \$name eq '.' or \$name eq '..'; \n
          The \$dh returns just the filename and does not include the directory path. 
          Globbing is different here because it does return the fully-qualified name.
          So to patch up the name to get the full name, we can use: \n
                \$name = "\$dirname/\$name";
                next unless -f \$name and -r \$name;   # only readable files.\n\n
 	}) =~ s/^ {4}//mg;
	print $message;
    print "    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '4i';
        &menu_1;         # Call subroutine to redraw this menu
        &option_4i;      # Call next option
    	}
}


sub option_4i {
    print "    OPTION: 4i - Directory Operations (Continued)";
    # next topic
	(my $message = qq{
          We can read a directory of files with the 'readdir' function.
 	}) =~ s/^ {4}//mg;
	print $message;

	my $location = 'C:\temp';
	print "      1. Determine if a directory exists at a location with the name: $location ";
	print '         opendir(my $dh, $location) || die ("Cannot opendir $location: $!");';

	#opendir(my $dh, $location) || die ("Cannot opendir $location: $!");
	# Problem: it finds only the . (current directory) and does not find the rest of the files
	#print "\n      2. Attempt to read files into an array with the \$dh, then close the \$dh ";
	#print '         my @files = readdir($dh) || die ("Cannot read dir: $! at $.");';
	#my @files = readdir($dh) || die ("Cannot read dir: $! at $.");
	#print '         #foreach $my_file (readdir $dh) {';
	#print '         foreach $my_file (@files) {';
	#print '             print "      one file in $location is $my_file";';
	#print '         }    closedir $dh;    # Problem: it does not find all the files';
	#my $my_file = '';
	##foreach $my_file (readdir $dh) {
	#foreach $my_file (@files) {
	#	print "      one file in $location is $my_file";
	#}
    #closedir $dh;

    # next topic
    # @dots = grep { /^\./ && -f "$some_dir/$_" } readdir($dh);
	print "\n      2. Attempt to read files in a loop with the \$dh, assign a scalar value ";
	print "      for each filename found, then close the \$dh    But it matches the . and ..";
	print '         my $my_file = \'\';';
	print '         foreach $my_file (readdir $dh) {';
	print '             print "      one file in $location is $my_file";';
	print '         }    closedir $dh;';
	my $my_file = '';
	opendir(my $dh, $location) || die ("Cannot opendir $location: $!");
	foreach $my_file (readdir $dh) {
		print "      one file in $location is $my_file";
	}
    closedir $dh;
	print "\n  So, 2. Attempt to read files in a loop with the \$dh, use an RE to match a ";
	print "      specific set of filenames and assign it to a scalar value, then close the \$dh ";
	print '         my @files = grep { substr($_, 0, 1) ne "." } readdir($dh);';
	opendir(my $dh, $location) || die ("Cannot opendir $location: $!");
	my @files = grep { substr($_, 0, 1) ne "." } (readdir $dh);
	print "\n         print \@files;   results: @files \n";
	#print '         my @htmlFiles = grep { /\.htm$/ } @files;';
	print "      The length of the array is: . scalar(\@files);   results: " . scalar(@files);
	print '         for my $file (@files) {';
	print '             print $file;';
	print '         }    closedir $dh;';
    closedir $dh;
	for my $file (@files) {
		print $file;
	}
	#my @htmlFiles = grep { /\*.htm$/ } @files;
	print "\n      3. Determine if any files exist in the directory: ";
	print '         print join ", ", @files if scalar(@files) > 0;';
	print join ", ", @files if scalar(@files) > 0;
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '4j';
        &menu_1;         # Call subroutine to redraw this menu
        &option_4j;      # Call next option
    	}
}


sub option_4j {
    print "    OPTION: 4j -  Directory Operations (Continued)\n";
	(my $message = qq{
          Then we can read a file with the 'readline' function.
	}) =~ s/^ {4}//mg;
	print $message;
    # next topic
	my $location = 'C:\temp';
	my $output_file = 'output.txt';
	opendir(my $dh, $location) || die ("Cannot opendir $location: $!");
	my @files = grep { substr($_, 0, 1) ne "." } (readdir $dh);
    closedir $dh;
	for my $input_file (@files) {
		open my $input_file_fh, '<', $input_file or die "      Could not open $input_file";
		#while my $line_read = ($input_file_fh) {
		#	next readline($input_file_fh);
		#}
		my $output_file_fh = $input_file_fh;
		open my $output_file_fh, '>', $output_file or die "       Could not open $output_file";
		open "File:  $input_file\n", '>>:encoding(UTF-8)', &output_file();
		close $input_file_fh;
		close $input_file_fh;
	}
	# chmod 0755 *.*

	#foreach my \$input_file ( qw( File- ) ) {
	#	say \$output_file \$input_file
	#}
	print '        opendir(my $dh, $location) || die ("Cannot opendir $location: $!");';
    print "        ";
    print '        ';

    print "        ";
    print '        ';

    print "        ";
    print '        ';
    print '        ';
    print '        ';
    print '        ';

    # next topic
	print '        my ($return_array, %return_hash, $return_scalar) = ObjectBuilder();';
	print '        my @rArray = my @return_array;';
	print '        my %rHash = %return_hash;';
	my ($return_array, %return_hash, $return_scalar) = ObjectBuilder();
	my @rArray = my @return_array;
	my %rHash = %return_hash;

	print '        print join ", ", @rArray;';
	print '        foreach my $myKey (keys %rHash) {';
	print '            print "$myKey = %rHash{$myKey}";';
	print '        }';
	print join ", ", @rArray;
	foreach my $myKey (keys %rHash) {
		print "$myKey = %rHash{$myKey}";
	}
    print "\n" x 2;
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '5b';
        &menu_1;         # Call subroutine to redraw this menu
        &option_5b;      # Call next option
    	}
}


sub option_5a {
    print "    OPTION: 5a - \n";
	(my $message = qq{
      
	}) =~ s/^ {4}//mg;
	print $message;
    # next topic
    
    # $- indicates the current page number
    format STDOUT_TOP =
    @|||||||||||||||||     Pg @<
    "Employee Data report",   $%
    
    .
    # $^L = Form Feed Variable
    # @< = current Page #
    # $% = 


    #Nice to use the 'Dumper Routine'
    use Data:Dumper qw(Dumper)
    $\ = "\n";

    print Dumper \@ARGV

    #Changing to just one parameter you can remove the references or
    $word = shift or die "Usage: $0 FILENAME";

    $argc = scalar(@ARGV);
    if($argc != 2){
    	print "Usage: $0 param1 param2";
    	exit;
    }

    ($word, $number) = @ARGV;
    #$word = $ARGV[0];
    #$number = $ARGV[1];
    print "The number you passed in is: $number";

    if ($word eq reverse $word) {
    	print "The word: $word is a palidrome";
    }

    #Three ways to  reate an array
    #1 create an empty array: ();
    #2 with elements: (1, 17, 19, 22)
    #with contiguous values (a range): (1..10) 

    # $0 has  aspecial meaning but it is not sequential
    # $1... has no meaning

    #Special Variable that does not require the my:

    # next topic
    # Create a simple report in Perl
    # Specify a default format:
    format =
    .
    # Save this as formatter.pl

    # Now: 
    # Formatter1.pl - An unnamed format
    # @< left-justified, 20 charachters.
    # Separated by 3 spaces
    # @> right-justified, 4 characters
    # Separated by 3 spaces
    # @#.## 5 characters
    # The @ symbol counts into the length
    # Open a FileHandle
    format =
    	@<<<<<<<<<<<<<<<<<<<   @>>>   @#.##
    	$steudent, $major, $gpa
    .
    open FH, ".\\ColemanStudents.txt" or die "Cannot open input file $! $.";

    @lines = <FH>;
    close FH;

    foreach (@lines) {
    	chop;
    	($student, $major, $gpa) = split /,/;
    	$student = "" if !defined($student);
    	$major = "" if !defined($major);
    	$gpa = "" if !defined($gpa);
    	write();
    }

    # Formatter2.pl - A named format
    format EMPLOYEE =
    @<<<<<<<<<  @>>   $@####
    $employee $age $salary
    
    .

    $= =8;
    $^L = "-" x 60 . "\n"
    	"Copyright, 2015, Custom Consulting\n";
    	"\n\n"

    # You can have your data here by associating STDOUT
    # with the named formatter with a two-step processing
    # 1st step
    @data = <DATA>;

    # 2nd step
    select(STDOUT);
    $~ = EMPLOYEE



    #foreach (@lines) {
    foreach (@data) {
    	chop;
    	($employee, $age, $salary) = split /,/;
    	$employee = '' if !defined($employee);
    	$age = '' if !defined($age);
    	$salary = '' if !defined($salary);
    	write();
    }

    # Form Feed Variable
    print "$^L";

    # Data read handle (an array of text data)
    __DATA__
    Bob Smith,55,59000



    print "\n" x 25;
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '5b';
        &menu_1;         # Call subroutine to redraw this menu
        &option_5b;      # Call next option
    	}
}


sub option_5b {
    print "    OPTION: 5b - \n";
	(my $message = qq{
      
	}) =~ s/^ {4}//mg;
	print $message;
    # next topic
    print "\n" * 2;
    print "\n    ${separator}${separator}";
    print "           Press the 'M' then 'Enter' keys to return to the main menu ";
    print "                 or press the 'Enter' key for the next topic... ";
	chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
	if ($_ eq '' ) { $_ = my $option; }	# assign default choice to loop last input on Enter Key
	my $option = $_;						# assign new default choice
    if ($option eq 'r') {
        $option = '6a';
        &display_menu_2(my $option);  # Call subroutine to redraw other menu with first option
    } elsif ($option ne 'm') {
        $option = '1a';
        &menu_1;         # Call subroutine to redraw this menu
        &option_1a;      # Call next option
    	}
}


sub trim {	
	# Trim leading and trailing whitespace with regular expression.
    # (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    return $s;        
	# Can also be done using the String::Util module's trim method.
	# Perl 6 will include a trim function. 
	# Ref: http://stackoverflow.com/questions/4597937
}


# There is no main routine in Perl
my $option = '1a';		# this global variable is the default starting menu topic
# Invoke subroutine (user-defined function). Ref 1, pg 63
# pass the default menu choice '1a' in the subroutine's parameter list
&display_menu_1($option);