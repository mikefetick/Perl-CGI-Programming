#!perl 	# C:\Perl64\perl executable can be found with the PATH key in the $ENV hash. Ref 1, pg 119
use 5.010;		# use at least version Perl 5.10 
use warnings;	# can use warnings pragma since Perl 5.6 ref 1, pg 28
use Win32::Console;				# On Windows, use the Win32::Console module

# 2/5/2015 Michael Fetick, 84270, COM330 Perl CGI Programming, C. Olsen, Coleman University
# Ref 1: Learning Perl, 6th Ed, O'Reilly
# perl -v (v5.20.1)

sub menu {
	my $choice;					# my (lexical variable) has private scope. Required with strict. Ref 1, pg 68
	($choice) = @_;				# use Perl's parameter list @_ . Ref 1, pg 67  
	while ($choice ne 'Q') {	# Outer loop while choice is not to Quit. Ref 1, pg 40
 		print "\n";
		print "                MENU\n";
		print "                ----\n";
		print "\n";
		print "        1a - Scalars\n";
		print "        1b - \n";
		print "        1c - \n";
		print "        2a - Arrays, @_ = (..)\n";
		print "        2b - \n";
		print "        2c - \n";
		print "        3a - \n";
		print "        3b - \n";
		print "        3c - \n";
		print "        4a - \n";
		print "        4b - \n";
		print "        4c - \n";
		print "        4d - \n";
		print "        4e - \n";
		print "        4f - \n";
		print "        4g - \n";
		print "        4h - \n";
		print "        4i - \n";
		print "         Q - Quit\n";
		print "\n";
		print "       >" . $choice . "\b\b";	# backspace to overwrite the choice with user editing
		chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
		if ($_ eq '' ) { $_ = $choice; }	# assign default choice to loop last input on Enter Key
		$choice = $_;						# assign new default choice
													# Clear screen before showing menu again
		system $^O eq 'MSWin32' ? 'cls' : 'clear';	# As of Perl 5.002, the language has the built-in $^O to indicate
													# which verion of Perl you are currently run on
													# Ref: http://stackoverflow.com/questions/4605593
		print "\n";
		given ( $_ ) {						# Like C's switch statement. Ref 1, pg 251
			# match, /i case insensitive		# invoke the subroutine for each menu option
			when ( /1a/ ) { &option_1a(); }	
			when ( /1b/ ) { &option_1b(); }
			when ( /1c/ ) { &option_1c(); }
			when ( /2a/ ) { &option_2a(); }
			when ( /2b/ ) { &option_2b(); }
			when ( /2c/ ) { &option_2c(); }
			when ( /3a/ ) { &option_3a(); }
			when ( /3b/ ) { &option_3b(); }
			when ( /3c/ ) { &option_3c(); }
			when ( /4a/ ) { &option_4a(); }
			when ( /4b/ ) { &option_4b(); }
			when ( /4c/ ) { &option_4c(); }
			when ( /4d/ ) { &option_4d(); }
			when ( /4e/ ) { &option_4e(); }
			when ( /4f/ ) { &option_4f(); }
			when ( /4g/ ) { &option_4g(); }
			when ( /4h/ ) { &option_4h(); }
			when ( /4i/ ) { &option_4i(); }
			when ( /Q/i ) { exit 0; } 			# Exit to quit, this way
			default { $choice = 'Q'; }			# Quit with anything else
		}
		# exit 0 if $choice =~ /^[Qq]/;				# or exit this way. Ref: http://perldoc.perl.org/functions/exit.html
		# die ", stopped" if $choice =~ /^[Qq]/;	# or die. Ref: http://perldoc.perl.org/functions/die.html
	}
}
sub option_4x {
	print "        4x - \n\n";
	# 
	# 
	my $location = "D:\\TEMP";
	print "Attempting to read location: $location";
	opendir(my $dh, $location) || die ("Cannot opendir $location: $!");
|	my @files = grep { substr($_, 0, 1) ne "." } readdir($dh);

	my @htmlFiles = grep { /^(\.[a-z])|\w+\.\w+/ | } @files;
	print "The length of the array is: " . scalar(@htmlFiles);
	for my $file (@htmlFiles) {
		print $file;
	}
}


}
sub option_5a {
	print "        5a - \n\n";
	# Look at the old Python comments on RE for more comments on RE - mvf
	# ...
	# Line anchors ^ $
	# Read a directory and iterate through the files
	my $location = "D:\\TEMP";
	opendir(my $dh, $location) || die ("Cannot opendir $location: $! $.");

	my @allFiles = readdir($dh) or die ("Cannot read dir: $! at $.");

	my @filtered = grep{substr($_, 0, 1) ne "."}@allFiles;

	# Version control programs: Git: .git and Subversion: .sun (starts with a period)
	# so we don't want to filter out the ones with the leading '.'
	# Use RE and the line anchors. Go through the list of files in the directory, 
	# eliminate the . and .. but keep the files that start with a period '.':
	foreach my $file (@allFiles) {
		next if ($file =~ /^\.(\)?$/);
	# RE are case-sensitive by default.
	}

	#print join ", " @files if scalar(@files) > 0;
	# These will match 'bled' and 'bleed': blee?d, ble+d, ble*d, ble{0,2}d, ble{2}d
}
sub option_5b {
	print "        5b - \n\n";
	# Create a regex that will match military time in hours:minutes:
	# \d, solve:
	#    0to19   20to23   :  00to59  
	# ^([01]\d | 2[0-3])$ : [0-5]\d


}
sub option_5c {
	print "        5c - \n\n";
	# Capture variable:
	# It remembers $1 $2
	# Week 7 CGI database assignment. Will use these capture variables
	#


}
sub option_E {
	print "        E - Extract and process string\n\n";
	print "        Enter a string >";
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	print "                        " . $userInput_1 . " has " . length($userInput_1) . " characters.\n";
}
sub option_P {
	print "        P - Perform a mathematical operation\n\n";
	print "        Enter a mathematical expression for PERL to evaluate >"; 
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	# Ref: http://www.regexlib.com/REDetails.aspx?regexp_id=2970
	my $result = '^ (?: (?> # non backtracking for alternated tokens (?: \- # "-" operator (?=\d|\() # followed by digit or "(" ) | (?: (?<=\d|\)) # preceded by digit or ")" (?:\+|\/|\*) # basic operators except "-" (?=\d|\(|\-) # followed by digit or "(" or "-" ) | (?<parenthesis> # incremente balancing group "parenthesis" counter (?<=^|\+|\/|\-|\*|\() # preceded by start of line or basic operator or "(" \( # opening parenthesis "(" (?=\d|\(|\-) # followed by digit or "-" or "(" ) | (?<-parenthesis> # decrement balancing group "parenthesis" counter (?<=\d|\)) # preceded by digit or ")" \) # opening parenthesis ")" (?!\d) # not followed by digit ) | (?: (?<=\(|\-|\+|\*|\/|^) # preceded by start of line or basic operator or "(" (?:\d+(?:\,\d{1,4})?) # number with optional 4 decimal with comma as decimal marker (?=$|\)|\-|\+|\*|\/) # followed by end of line or ")" or basic operator ) ) + (?(parenthesis)(?!)) # test for balancing group "parenthesis" counter ) # unnamed group whole expression $';
	# ,^ (?: (?> # non backtracking for alternated tokens (?: \- # "-" operator (?=\d|\() # followed by digit or "(" ) | (?: (?<=\d|\)) # preceded by digit or ")" (?:\+|\/|\*) # basic operators except "-" (?=\d|\(|\-) # followed by digit or "(" or "-" ) | (?<parenthesis> # incremente balancing group "parenthesis" counter (?<=^|\+|\/|\-|\*|\() # preceded by start of line or basic operator or "(" \( # opening parenthesis "(" (?=\d|\(|\-) # followed by digit or "-" or "(" ) | (?<-parenthesis> # decrement balancing group "parenthesis" counter (?<=\d|\)) # preceded by digit or ")" \) # opening parenthesis ")" (?!\d) # not followed by digit ) | (?: (?<=\(|\-|\+|\*|\/|^) # preceded by start of line or basic operator or "(" (?:\d+(?:\,\d{1,4})?) # number with optional 4 decimal with comma as decimal marker (?=$|\)|\-|\+|\*|\/) # followed by end of line or ")" or basic operator ) ) + (?(parenthesis)(?!)) # test for balancing group "parenthesis" counter ) # unnamed group whole expression $';
	print "                        " . $userInput_1 . " = " . $result . "\n";
}
sub option_R {
	print "        R - Read a directory of files\n\n";
	print "        Enter a directory's name  >";
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	print "\n";
	system $^O eq 'MSWin32' ? 'dir ' . $userInput_1 : 'pwd ' . $userInput_1;
}
sub option_F {
	print "        F - Find a pattern in a list of files\n\n";
	print "        At what directory? >";
	$dirSearch = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
												# no need to chomp
	print "        Enter a pattern to look for  >";
	$pattern = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
												# no need to chomp
	print "        Resulted matches of pattern among all lines of all files in a directory listed below:\n";
	# Ref: http://stackoverflow.com/questions/1512729
	{
		#my ($fileList) = (system $^O eq 'MSWin32' ? 'dir /w' . $dirSearch : 'ls -l' . $dirSearch);
		#local @ARGV = ($fileList);
		#foreach ($ARGV) {
		#	print "$ARGV:$.:$_" if /Okay/;
		#} continue {
		#	close ARGV if eof;
		#}
	}
}
sub option_L {
	print "        L - Determine if a word is a palindrome\n\n";
	print "        Enter a string >";
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	# Ref: http://stackoverflow.com/questions/15752965
	if ($userInput_1 ne "") {
		my ($word) = $userInput_1;

		my @chars = split //, $word;
		my $palindrome = 1;
		for (0..@chars/2-1) {
			$palindrome = $chars[$_] eq $chars[-($_+1)]
			or last;
		}
		print "                        $word ".($palindrome ? "is" : "isn't")." a palindrome\n";
	}
}
sub trim {	
	# Trim leading and trailing whitespace with regular expression.
    # (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    return $s;        
	# Can also be done using the String::Util module's trim method.
	# Perl 6 will include a trim function. 
	# Ref: http://stackoverflow.com/questions/4597937
}
# There is no main routine in Perl
$default = '5a';		# global variable
# Invoke subroutine (user-defined function). Ref 1, pg 63
&menu($default);		# pass the default menu choice 'E' in the subroutine's parameter list
