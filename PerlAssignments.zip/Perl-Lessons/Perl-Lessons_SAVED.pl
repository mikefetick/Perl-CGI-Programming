#!perl 	# C:\Perl64\perl executable can be found with the PATH key in the $ENV hash. Ref 1, pg 119
use 5.010;		# use at least version Perl 5.10 
# no warnings;	# can use warnings pragma since Perl 5.6 ref 1, pg 28
use Win32::Console;				# On Windows, use the Win32::Console module
use strict;
use diagnostics;
								# Uncomment lines 4 and 34 to clear the screen
# use Term::ANSIScreen qw(cls);	# On Unix, you may need to install the module and import the cls function
								# Just use the ActiveState port of Perl's Perl Package Manager (PPM). Ref 1, Pg 191
								# or download Term-ANSIScreen-1.50.tar.gz (31.4 KB) from cspan.org

# 1/8/2015 Michael Fetick, 84270, COM330 Perl CGI Programming, Chris Olsen, Coleman University
# Ref 1: Learning Perl, 6th Ed, O'Reilly
# perl -v (v5.20.1)

sub menu {
	my $choice;					# the word 'my' is a lexical variable that has private scope. 
								# It is required for variables when using strict. Ref 1, pg 68
	($choice) = @_;				# use Perl's parameter list @_ . Ref 1, pg 67  
	while ($choice ne 'Q') {	# Outer loop while choice is not to Quit. Ref 1, pg 40
 		print "\n";
		print "                MENU\n";
		print "                ----\n";
		print "\n";
		print "        1a - Scalars\n";
		print "        1b - \n";
		print "        1c - \n";
		print "        2a - Arrays, @_ = (..)\n";
		print "        2b - \n";
		print "        2c - \n";
		print "        3a - \n";
		print "        3b - \n";
		print "        3c - \n";
		print "        4a - \n";
		print "        4b - \n";
		print "        4c - \n";
		print "        4d - \n";
		print "        4e - \n";
		print "        4f - \n";
		print "        4g - \n";
		print "        4h - \n";
		print "        4i - \n";
		print "         Q - Quit\n";
		print "\n";
		print "       >" . $choice . "\b\b";	# backspace to overwrite the choice with user editing
		chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
		if ($_ eq '' ) { $_ = $choice; }	# assign default choice to loop last input on Enter Key
		$choice = $_;						# assign new default choice
													# Clear screen before showing menu again
		system $^O eq 'MSWin32' ? 'cls' : 'clear';	# As of Perl 5.002, the language has the built-in $^O to indicate
													# which verion of Perl you are currently run on
													# Ref: http://stackoverflow.com/questions/4605593
		print "\n";
		given ( $_ ) {						# Like C's switch statement. Ref 1, pg 251
			# match, /i case insensitive		# invoke the subroutine for each menu option
			when ( /1a/ ) { &option_1a(); }	
			when ( /1b/ ) { &option_1b(); }
			when ( /1c/ ) { &option_1c(); }
			when ( /2a/ ) { &option_2a(); }
			when ( /2b/ ) { &option_2b(); }
			when ( /2c/ ) { &option_2c(); }
			when ( /3a/ ) { &option_3a(); }
			when ( /3b/ ) { &option_3b(); }
			when ( /3c/ ) { &option_3c(); }
			when ( /4a/ ) { &option_4a(); }
			when ( /4b/ ) { &option_4b(); }
			when ( /4c/ ) { &option_4c(); }
			when ( /4d/ ) { &option_4d(); }
			when ( /4e/ ) { &option_4e(); }
			when ( /4f/ ) { &option_4f(); }
			when ( /4g/ ) { &option_4g(); }
			when ( /4h/ ) { &option_4h(); }
			when ( /4i/ ) { &option_4i(); }
			when ( /Q/i ) { exit 0; } 			# Exit to quit, this way
			default { $choice = 'Q'; }			# Quit with anything else
		}
		# exit 0 if $choice =~ /^[Qq]/;				# or exit this way. Ref: http://perldoc.perl.org/functions/exit.html
		# die ", stopped" if $choice =~ /^[Qq]/;	# or die. Ref: http://perldoc.perl.org/functions/die.html
	}
}
sub option_1a {
	print "        1a - \n\n";
}
sub option_1b {
	print "        1b - \n\n";
}
sub option_1c {
	print "        1c - \n\n";
}
sub option_2a {
	my $separator = ("*" x 50)."\n\n";
	print "        2a - \n\n";
	print '        Arrays: The sigel is @'."\n\n";
	my @simple = (7, 8, 9);
	print '        @simple = (7, 8, 9);'."\n";
	print '        print "Variable @simple - resolved in double-quoted text;'."\"\n";
	print "               Variable @simple - resolved in double-quoted text\n\n";
	print "        print 'Variable ".'@simple'." - not resolved in single-quoted text;'\n";
	print '               Variable @simple - not resolved in single-quoted text'."\n\n";


	print '        print "Concate to text ".@simple." - returns the array\'s element count"'."\n";
	print "               Concate to text ".@simple." - returns the array's element count\n\n";
	print '        print @simple;';
	print "   # print the variable by itself\n";
	print @simple;
	print "     # did not print whitespace or a new line\n\n";
	#$simple[0] = 1;
	#$simple[1] = 2;
	#$simple[2] = 3;
	print "        print \'\$simple[0] = '.\"\$simple[0]\\n\"\n";
	print "        print \'\$simple[1] = '.\"\$simple[1]\\n\"\n";
	print "        print \'\$simple[2] = '.\"\$simple[2]\\n\"\n";
	print '$simple[0] = '."$simple[0]\n";
	print '$simple[1] = '."$simple[1]\n";
	print '$simple[2] = '."$simple[2]\n\n";
	print "        print \@simple[0]    # it is better written with the \$;\n";
	print "        print \"\$simple[0]\"  # it is better written to leave out the quotes;\"\n";
	print "        print \$simple[0];\n";
	print $simple[0];
	print "\n        print \@simple[0..2];\n";
	print @simple[0..2];
	print "     # unless you have to use the @ with the range of numeric elements\n";
	print "        # did not print whitespace or a new line\n\n";
}
sub option_2b {
	print "        2b - \n\n";
	my @array = (1, 2, 3);

	my @emptyArray = ();
	push @emptyArray, $_ for (1..15); 
	foreach (@emptyArray) {
		print;
	}
	print "\n\n";
	# another example
	push @array, $_ for 4..8;
	printf "value %d\n", shift @array while @array;
	# shift - grab first item and remove it. It changed the contents of the array.
	foreach (@emptyArray) {
		print;
	}
	print "\n\n";
	# another example
	@array = ('Larry', 'Curly', 'Moe');
	print "\n\n";
	# Equivalent statement...
	my $size = scalar(@array);
	while ($size > 0) {
		printf "value %s\n", shift @array;
		$size = scalar(@array);
	}
	print "My stooges are: ".join(", ", @array)."\n";
	# join( delimiter, the array ) it converts Ints into Strings so do last, after mathematical operations
	# shift removes the item.
	# unshift puts the item back.
}
sub option_2c {
	print "        2c - \n\n";
} 

sub HandleHash
{
	print " ";
}


sub option_3a {
	# $\ = "\n";
	print "        3a - \n\n";
	print '        Hash: The sigel is \%'."\n\n";
	my %areaCodesOLD = {"619", "San Diego", "415", "San Francisco", "707", "San Rosa"};
	my %areaCodes = {"619" => "San Diego", "714" => "Orange County", "415" => "San Francisco", "707" => "San Rosa"};
	print %areaCodes;

	while ((my $key, my $value) = each(%areaCodes)) {
		print $key . " => " . $value;
	
	&Multiply(11);
	&Multiply2(11, 15);
	&Multiply3(7, 5);
	&Multiply4(7, 7);

	print my $separator;
	print "Print a hash: 1";
	while (($key, $value) = each(%areaCodes)) {
		print $key . " => " . $value;
	}

	print $separator;
	print "Print a hash: 2";
	for my $ac (keys my %data) {
		print $data{$ac};
	}

	print $separator;
	print "Print a hash: 3";
	foreach my $k (keys my %data) {
		print $data{$k};
	}

	print $separator;
	my @names = keys my %data;
	foreach (@names) {print}

	# Checking to see if the key exists
	print $separator;
	if (exists($data{'805'})) {
		print "805 is $data{'805'}\n";
	} else {
		print "805 is not in the hash.\n";
	}

	# Checking to see how many items are
	print $separator;
	if (exists($data{'805'})) {
		print "805 is $data{'805'}\n";
	} else {
		print "805 is not in the hash.\n";
	}

}
sub Multiply
{
	my $first = $_[0];
	my $second = $_[1];

	# print "Undefined..." if undef($second)
	return $first * $second;
}
sub Multiply2
{
	my $first = shift;
	my $second = shift;

	return $first * $second;
}
sub Multiply3
{
	my ($first, $second) = @_;
	return $first * $second;
}

sub Multiply4
{
	(my $first, my $second) = @_;
	$first * $second;
}

sub HandleArrays
{
	# @myNumbers = shift;
	my @myNumbers = @{$_[0]};
	# @myNumbers = @_
	# @myNumbers = {shift};   # Do not use this!
	say $_[1];  

	#print $saying;
	foreach my $item(@myNumbers) {
		print $item;
	}
}
sub option_3b {
	print "        3b - Passing Arrays or a list into subroutines.\n\n";

	my @numbers = (5, 6, 7);
	&HandleArrays(@numbers);
}
sub option_3c {
	print "        3c - \n\n";

	my $data = "lowercase data";
	print uc($data);

	my $newdata = $data =~ tr/a-z/A-Z/;
	print $newdata;

	my $string = $data =~ tr/abcdefghij/012345789/;
	print $string;
	
	print index my $input, 'is';    # '2'
	print substr $input, 5;       # 'is a test.''
	print substr $input, 5, 7;   # 'is a te'

	my $newINPUT = "THIS IS A TEST";
	print "Eureka!" if ($input =~ /is/gi);  #  'is'

	my $expr = "This is a test";
	print $expr =~ tr/iat/943/;  # inline transliteration
	$expr =~ tr/iat/943/;
	print $expr;

	$_ = "this is a string";
	s/ /_/g;   # replace all the spaces with the underscore, globally
	print;
	# $newInput = =~ tr/is/wz/;

	print my $newInput;
	print "Start entering some data: ";
	while (<>) {
		tr/a-z/A-Z/;  # the tr is the transliteration operator
		print;

	}
}

sub DumpNumber {
	my @myNumbers = @{$_[0]};
	#1st parameter = delimiter, will be used as a scalar
	print join ", ", @myNumbers;
}
sub DumpContainer {
	my @myNumbers = @{shift @_}; 	# my @myNumbers = @{shift @_};
	my %myHash = %{shift @_};
	print "\n";
	print join ", ", @myNumbers;
	print join "\n";
	foreach my $item (keys my %myHash) {
		print $item . " = " . $myHash{$item} . "\n";
}
sub DumpNumber2 {
	my @myNumbers = @{shift @_};
	print join ", ", @myNumbers;
	print join "\n" . ("-" x 50) . "\n";
}
sub DumpHash {
	my %myHash = %{shift @_};
	foreach my $item (keys %myHash) {
		print $item . " = " . $myHash{$item} . "\n";
	}
}

my ($return_array, %return_hash, $return_scalar) = ObjectBuilder();
my @rArray = my @return_array;
my %rHash = %return_hash;

print join ", ", @rArray;
foreach my $myKey (keys %rHash) {
	print "$myKey = %rHash{$myKey}";
}

# Build constructs and return them to the caller
sub ObjectBuilder {
	# Preface my variables with my
	my @myArray = ( 20..25 );
	my %myHash = ( "KRON" => "Los Angeles", "KGTV" => "San Deigo",
					"KGO" => "San Francisco", "KFMB" => "San Diego");
	return (\@myArray, \%myHash, my $scalarValue);   # The '\' means you are passing the reference
}

#DumpContainer(my \@number, my \%zipCodes);

sub option_4a {
	print "        4a - \n\n";
	my $line = ("-" x 50) . "\n";
	my $single = 1;
	my @number = (1..5);
	my %zipCodes = ("92111" => "Kerney Mesa",    "92109" => "Pacific Beach",
			        "92108" => "Mission Valley", "91941" => "La Mesa",
			        "92126" => "Mira Mesa",      "92101" => "Downtown");

	DumpNumber(\@number);
	DumpNumber2(\@number);

	# @_ is the first item in the array
	# shift
	# list assignment. Use @{$_[0]} to force it to be a list.
	# pass 1st string parameter, the 2nd param is the list
}
sub option_4b {
	# Sorting in Perl
	use strict;
	$\ = "n";

	my $line = ("-" x 50);
	my @not_sorted = (303, 5, 209, 777, 51, 38);
	my @sorted = sort { $a <=> $b } @not_sorted;  # sorts the numbers oin numeric comparison
	# out of placee sort assigns the result to a variable
	print "@sorted\n";

	my @strings = qw / this school is located on balboa ave/;
	my @sorted_strings = sort { $a cmp $b } @strings;
	# for strings no not use the spacehip operator, use the compare.
	# strcmp returns -1, 0, 1, so "abc" > "ABC", (97, 98, 99) > (65, 66, 67) (colation sequence)
	print "@sorted_strings\n";

	my @reverse = sort { $b cmp $a } qw /the rain in spain falls on the plain/;
	print @reverse;


	# Perl has separate operators when comparing numbers than comparing strings
	my $val1 = 55;
	my $val2 = 66;
	if ($val1 > $val2) {
		# // True or 1 
	}
	# Do an 'out of place' sort
	my $str1 = "xyz";
	my $str2 = "XYZ";
	if ($str1 lt $str2) {
		# // True or 1 
	}

	# The sorting operator is like the Star War's spaceship operator <=>

	print "        4b - \n\n";
}

sub Square {
	my $number = shift;
	return $number * $number;
}
sub option_4c {
	print "        4c - \n\n";

	# Look at mapping, grep, data-dumping module
	use Data::Dumper qw(Dumper);
	$\ = "\n";
	my $line = "\n" x 50;

	# We all should be able to create a list using a line syntax with a range of numbers
	my @numbers = (1..10);
	my @squareNumbers = ();

	print "@numbers\n";
	foreach my $number (@numbers) {
		push(my @squareNumbers, Square(my $numbers));
	}

	print "@squareNumbers\n";

	my @mappedNumbers = map { $_ * $_ } @numbers;
	print "@mappedNumbers\n";

	@mappedNumbers = map { Square($_) } @numbers;
	print "@mappedNumbers\n";
}
sub option_4d {
	# Another example to use the map to load up the contents of a hash
	# Handy when you want to initialize all the values of a hash
	my @names = qw /thomas brian steven james/;
	my %is_invited = map { $_ => 1..4} @names;

	print "Iterating through the hash";
	while ((my $keys, my $value) = each(%is_invited)) {
		print "$keys: $value";
	}
	print "Enter a name: ";
	my $visitor = <STDIN>;
	chomp($visitor);

	if ($is_invited{$visitor}) {
		print "The visitor $visitor is here";
	}
	# The map function is most useful. It transforms a collection of data to a hash.
	# We can do more than one line... 
	# We can change the contents of an array

	my @middleNames = qw /sammy larry bobby jimmy/;
	my @newMiddleNames = map { ucfirst } @middleNames;
	print "@newMiddleNames\n";

	my @firstNames = qw /joe steven robert larry freddie/;
	my @everyone = map {
		uc,
		$_, ucfirst . "'s car"
	} @firstNames;
	print "@everyone\n";

	# Create a hash
	my %nameHash = ("thomas" => 1,
					"james" => 2,
					"steven" => 3,
					"brian" => 4);

}
sub option_4e {
	# 
	# 
	my $sentence = "I would like to go to london this year";
	print "\$sentence before: $sentence";
	$sentence =~ s/London/London/;
}
sub option_4f {
	# grep seraches for a pattern 
	# Perl can search heterogeneous arrays – of different types 
	my @h_array = (1, "Test", 55, "foo", 65, 20);
	my @has_digits = grep /-?\d+(\.\d+)/, @h_array;  # (1, 655, 65, 20)

	print join ", ", @has_digits;
}
sub option_4g {
	# use the grep utility to filter out words less than eight characters
	# 
	my @products = qw /potatoes lemons apricots apples banannas pineapple/;
	# Use back slashes / / for string comparisons 
	# Use braces {} when doing a call to a built-in function, i.e. length, count 
	my @small_words = grep { length $_ < 8 } @products;
	for my $index (@small_words) {
		print $index;
	}

	my $location = "D:\\TEMP";
	print "Attempting to read location: $location";
	opendir(my $dh, $location) || die ("Cannot opendir $location: $!");

	my @files = readdir("$location") or die ("Cannot read dir: $! at $.");
	print join ", ", @files if scalar(@files) > 0;

}
sub option_4h {
    # opendir(my $dh, $some_dir) || die "can't opendir $some_dir: $!";
    # @dots = grep { /^\./ && -f "$some_dir/$_" } readdir($dh);
    # closedir $dh;
	my $location = "D:\\TEMP";
	print "Attempting to read location: $location";
	opendir(my $dh, $location) || die ("Cannot opendir $location: $!");
	my @files = grep { substr($_, 0, 1) ne "." } readdir($dh);
	my @htmlFiles = grep { /\.html$/ } @files;
	print "The length of the array is: " . scalar(@htmlFiles);
	for my $file (@htmlFiles) {
		print $file;
	}
}
sub trim {	
	# Trim leading and trailing whitespace with regular expression.
    # (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    return $s;        
	# Can also be done using the String::Util module's trim method.
	# Perl 6 will include a trim function. 
	# Ref: http://stackoverflow.com/questions/4597937
}
# There is no main routine in Perl
my $default = '1a';		# this global variable is the default starting menu topic
# Invoke subroutine (user-defined function). Ref 1, pg 63
# pass the default menu choice '1a' in the subroutine's parameter list
#&menu($default)
&menu('1a');
