#!perl 	# C:\Perl64\perl executable can be found with the PATH key in the $ENV hash. Ref 1, pg 119
use 5.010;		# use at least version Perl 5.10 
use warnings;	# can use warnings pragma since Perl 5.6 ref 1, pg 28
use Win32::Console;				# On Windows, use the Win32::Console module
use strict;
								# Uncomment lines 4 and 34 to clear the screen
# use Term::ANSIScreen qw(cls);	# On Unix, you may need to install the module and import the cls function
								# Just use the ActiveState port of Perl's Perl Package Manager (PPM). Ref 1, Pg 191
								# or download Term-ANSIScreen-1.50.tar.gz (31.4 KB) from cspan.org

# 1/8/2015 Michael Fetick, 84270, COM330 Perl CGI Programming, Chris Olsen, Coleman University
# Ref 1: Learning Perl, 6th Ed, O'Reilly
# perl -v (v5.20.1)

sub menu {
	my $choice;					# my (lexical variable) has private scope. Ref 1, pg 68
	($choice) = @_;				# use Perl's parameter list @_ . Ref 1, pg 67  
	while ($choice ne 'Q') {	# Outer loop while choice is not to Quit. Ref 1, pg 40
 		print "\n";
		print "                MENU\n";
		print "                ----\n";
		print "\n";
		print "        1a - Scalars\n";
		print "        1b - \n";
		print "        1c - \n";
		print "        2a - Arrays, @_ = (..)\n";
		print "        2b - \n";
		print "        2c - \n";
		print "        3a - \n";
		print "        3b - \n";
		print "        3c - \n";
		print "        4a - \n";
		print "        4b - \n";
		print "        4c - \n";
		print "        4d - \n";
		print "        4e - \n";
		print "        4f - \n";
		print "        4g - \n";
		print "        4h - \n";
		print "        4i - \n";
		print "         Q - Quit\n";
		print "\n";
		print "       >" . $choice . "\b\b";	# backspace to overwrite the choice with user editing
		chomp($_ = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
		if ($_ eq '' ) { $_ = $choice; }	# assign default choice to loop last input on Enter Key
		$choice = $_;						# assign new default choice
													# Clear screen before showing menu again
		system $^O eq 'MSWin32' ? 'cls' : 'clear';	# As of Perl 5.002, the language has the built-in $^O to indicate
													# which verion of Perl you are currently run on
													# Ref: http://stackoverflow.com/questions/4605593
		print "\n";
		given ( $_ ) {						# Like C's switch statement. Ref 1, pg 251
			# match, /i case insensitive		# invoke the subroutine for each menu option
			when ( /1a/ ) { &option_1a(); }	
			when ( /1b/ ) { &option_1b(); }
			when ( /1c/ ) { &option_1c(); }
			when ( /2a/ ) { &option_2a(); }
			when ( /2b/ ) { &option_2b(); }
			when ( /2c/ ) { &option_2c(); }
			when ( /3a/ ) { &option_3a(); }
			when ( /3b/ ) { &option_3b(); }
			when ( /3c/ ) { &option_3c(); }
			when ( /4a/ ) { &option_4a(); }
			when ( /4b/ ) { &option_4b(); }
			when ( /4c/ ) { &option_4c(); }
			when ( /4d/ ) { &option_4d(); }
			when ( /4e/ ) { &option_4e(); }
			when ( /4f/ ) { &option_4f(); }
			when ( /4g/ ) { &option_4g(); }
			when ( /4h/ ) { &option_4h(); }
			when ( /4i/ ) { &option_4i(); }
			when ( /Q/i ) { exit 0; } 			# Exit to quit, this way
			default { $choice = 'Q'; }			# Quit with anything else
		}
		# exit 0 if $choice =~ /^[Qq]/;				# or exit this way. Ref: http://perldoc.perl.org/functions/exit.html
		# die ", stopped" if $choice =~ /^[Qq]/;	# or die. Ref: http://perldoc.perl.org/functions/die.html
	}
}
sub option_1a {
	print "        1a - \n\n";
}
sub option_1b {
	print "        1b - \n\n";
}
sub option_1c {
	print "        1c - \n\n";
}
sub option_2a {
	my $separator = ("*" x 50)."\n\n";
	print "        2a - \n\n";
	print '        Arrays: The sigel is @'."\n\n";
	@simple = (7, 8, 9);
	print '        @simple = (7, 8, 9);'."\n";
	print '        print "Variable @simple - resolved in double-quoted text;'."\"\n";
	print "               Variable @simple - resolved in double-quoted text\n\n";
	print "        print 'Variable ".'@simple'." - not resolved in single-quoted text;'\n";
	print '               Variable @simple - not resolved in single-quoted text'."\n\n";


	print '        print "Concate to text ".@simple." - returns the array\'s element count"'."\n";
	print "               Concate to text ".@simple." - returns the array's element count\n\n";
	print '        print @simple;';
	print "   # print the variable by itself\n";
	print @simple;
	print "     # did not print whitespace or a new line\n\n";
	#$simple[0] = 1;
	#$simple[1] = 2;
	#$simple[2] = 3;
	print "        print \'\$simple[0] = '.\"\$simple[0]\\n\"\n";
	print "        print \'\$simple[1] = '.\"\$simple[1]\\n\"\n";
	print "        print \'\$simple[2] = '.\"\$simple[2]\\n\"\n";
	print '$simple[0] = '."$simple[0]\n";
	print '$simple[1] = '."$simple[1]\n";
	print '$simple[2] = '."$simple[2]\n\n";
	print "        print \@simple[0]    # it is better written with the \$;\n";
	print "        print \"\$simple[0]\"  # it is better written to leave out the quotes;\"\n";
	print "        print \$simple[0];\n";
	print $simple[0];
	print "\n        print \@simple[0..2];\n";
	print @simple[0..2];
	print "     # unless you have to use the @ with the range of numeric elements\n";
	print "        # did not print whitespace or a new line\n\n";
}
sub option_2b {
	print "        2b - \n\n";
	@array = (1, 2, 3);

	@emptyArray = ();
	push @emptyArray, $_ for (1..15); 
	foreach (@emptyArray) {
		print;
	}
	print "\n\n";
	# another example
	push @array, $_ for 4..8;
	printf "value %d\n", shift @array while @array;
	# shift - grab first item and remove it. It changed the contents of the array.
	foreach (@emptyArray) {
		print;
	}
	print "\n\n";
	# another example
	@array = ('Larry', 'Curly', 'Moe');
	print "\n\n";
	# Equivalent statement...
	$size = scalar(@array);
	while ($size > 0) {
		printf "value %s\n", shift @array;
		$size = scalar(@array);
	}
	print "My stooges are: ".join(", ", @array)."\n";
	# join( delimiter, the array ) it converts Ints into Strings so do last, after mathematical operations
	# shift removes the item.
	# unshift puts the item back.
}
sub option_2c {
	print "        2c - \n\n";
} 

%class = 

sub HandleHash
{
	print
}


sub option_3a {
	# $\ = "\n";
	print "        3a - \n\n";
	print '        Hash: The sigel is %'."\n\n";
	%areaCodesOLD = {"619", "San Diego", "415", "San Francisco", "707", "San Rosa"};
	%areaCodes = {"619" => "San Diego", "714" => "Orange County", "415" => "San Francisco", "707" => "San Rosa"};
	print %areaCodes;

	while (($key, $value) = each(%areaCodes)) {
		print $key . " => " . $value;
	
	&Multiply(11);
	&Multiply2(11, 15);
	&Multiply3(7, 5);
	&Multiply4(7, 7);

	print separator;
	print "Print a hash: 1"
	while (($key, $value) = each(%areaCodes)) {
		print $key . " => " . $value;
	}

	print separator;
	print "Print a hash: 2"
	for $ac (keys %data) {
		print $data{$ac};
	}

	print separator;
	print "Print a hash: 3"
	foreach $k (keys %data) {
		print $data{$k};
	}

	print separator;
	@names = keys %data;
	foreach (@names) {print}

	# Checking to see if the key exists
	print $separator;
	if (exists($data{'805'})) {
		print "805 is $data{'805'}\n";
	else
		print "805 is not in the hash.\n";
	}

	# Checking to see how many items are
	print $separator;
	if (exists($data{'805'})) {
		print "805 is $data{'805'}\n";
	else
		print "805 is not in the hash.\n";
	}

}
sub Multiply
{
	$first = $_[0];
	$second = $_[1];

	# print "Undefined..." if undef($second)
	return $first * $second;
}
sub Multiply2
{
	$first = shift;
	$second = shift;

	return $first * $second;
}
sub Multiply3
{
	($first, $second) = @_;
	return $first * $second;
}

sub Multiply4
{
	($first, $second) = @_;
	$first * $second;
}

sub HandleArrays
{
	# @myNumbers = shift;
	@myNumbers = @{$_[0]};
	# @myNumbers = @_
	# @myNumbers = {shift};   # Do not use this!
	$saying = $_[1];  

	print $saying;
	foreach $item(@myNumbers) {
		print $item;
	}
}
sub option_3b {
	print "        3b - Passing Arrays or a list into subroutines.\n\n";

	@numbers = (5, 6, 7);
	&HandleArrays(@numbers);
}
sub option_3c {
	print "        3c - \n\n";

	$data = "lowercase data";
	print uc($data);

	$newdata = $data =~ tr/a-z/A-Z/;
	print $newdata;

	$string =~ $data =~ tr/abcdefghij/0123457890/;
	print $string
	
	print index $input, 'is';    # '2'
	print substr $input, 5;       # 'is a test.''
	print substr $input, 5, 7;   # 'is a te'

	$newINPUT = "THIS IS A TEST";
	print "Eureka!" if ($input =~ /is/gi);  #  'is'

	$expr = "This is a test"
	print $expr =~ tr/iat/943/;  # inline transliteration
	$expr =~ tr/iat/943/;
	print $expr;

	$_ = "this is a string";
	s/ /_/g;   # replace all the spaces with the underscore, globally
	print;
	# $newInput = =~ tr/is/wz/;

	print $newInput;
	print "Start entering some data: "
	while (<>) {
		tr/a-z/A-Z/;  # the tr is the transliteration operator
		print;

	}
}

sub DumpNumber {
	my @myNumbers = @{$_[0]};
	#1st parameter = delimiter, will be used as a scalar
	print join ", ", @myNumbers;
}
sub DumpContainer {
	my @myNumbers = @{shift @_}; 	# my @myNumbers = @{shift @_};
	my @myHash = %{shift @_};
	print "\n";
	print join ", ", @myNumbers;
	print join "\n";
	foreach my $item (keys %myHash) {
		print $item . " = " . $myHash{$item} . "\n";
}
sub DumpNumber2 {
	my @myNumbers = @{shift @_};
	print join ", ", @myNumbers;
	print join "\n" . ("-" x 50) . "\n";
}
sub DumpHash {
	my %myHash = %{shift @_};
	foreach my $item (keys %myHash) {
		print $item . " = " . $myHash{$item} . "\n";
	}
}

my ($return_array, $return_hash, $return_scalar) = ObjectBuilder();
my @rArray = @return_array;
my %rHash = %$return_hash;

print join ", " @rArray;
foreach my $myKey (keys %rHash) {
	print "$myKey = $rHash{$myKey}";
}

# Build constructs and return them to the caller
sub ObjectBuilder {
	# Preface my variables with my
	my @myArray = ( 20..25 );
	my %myHash = ( "KRON" => "Los Angeles", "KGTV" => "San Deigo"
					"KGO" => "San Francisco", "KFMB" => "San Diego");
	return (\@myArray, \%myHash, $scalarValue);   # The '\' means you are passing the reference
}

DumpContainer(\@number, \%zipCodes);

sub option_4a {
	print "        4a - \n\n";
	my $line = ("-" x 50) . "\n";
	my $single = 1;
	my @number = (1..5);
	my %zipCodes = ("92111" => "Kerney Mesa", "92109" => "Pacific Beach",
					"") # NOT FINISJED HERE

	DumpNumber(\@number);
	DumpNumber2(\@number);

	# @_ is the first item in the array
	# shift
	# list assignment. Use @{$_[0]} to force it to be a list.
	# pass 1st string parameter, the 2nd param is the list
}
sub option_4b {
	# Sorting in Perl
	use strict;
	$\ = "n";

	my $line = ("-" x 50);
	my @not_sorted = (303, 5, 209, 777, 51, 38);
	my @sorted = sort { $a <=> $b } @not_sorted;  # sorts the numbers oin numeric comparison
	# out of placee sort assigns the result to a variable
	print "@sorted\n"

	my @strings = qw / this school is located on balboa ave/;
	my @sorted_strings = sort { $a cmp $b } @strings;
	# for strings no not use the spacehip operator, use the compare.
	# strcmp returns -1, 0, 1, so "abc" > "ABC", (97, 98, 99) > (65, 66, 67) (colation sequence)
	print "@sorted_strings\n"

	my @reverse = sort { $b cmp $a } qw /the rain in spain falls on the plain/;
	print @reverse;


	# Perl has separate operators when comparing numbers than comparing strings
	my $val1 = 55;
	my $val2 = 66;
	if ($val1 > $val2) {
		# // True or 1 
	}
	# Do an 'out of place' sort
	my $str1 = "xyz";
	my $str2 = "XYZ";
	if ($str1 lt $str2) {
		# // True or 1 
	}

	# The sorting operator is like the Star War's spaceship operator <=>

	print "        4b - \n\n";
}

sub Square {
	my $number = shift;
	return $number * $number;
}
sub option_4c {
	print "        4c - \n\n";

	# Look at mapping, grep, data-dumping module
	use Data::Dumper qw(Dumper);
	$\ = "\n";
	my $line = "\n" x 50;

	# We all should be able to create a list using a line syntax with a range of numbers
	my @numbers = (1..10);
	my @squareNumbers = ();

	print "@numbers\n";
	foreach my $number (@numbers) {
		push(squareNumbers, Square($numbers));
	}

	print "@squareNumbers\n";

	my @mappedNumbers = map { $_ * $_ } @numbers;
	print "@mappedNumbers\n";

	my @mappedNumbers = map { Square($_) } @numbers;
	print "@mappedNumbers\n";
}
sub option_4d {
	# Another example to use the map to load up the contents of a hash
	# Handy when you want to initialize all the values of a hash
	my @names = qw /thomas brian steven james/;
	my %is_invited map { $_ => 1 ..} @names;

	print "Iterating through the hash";
	while (my $keys, $value) = each %is_invited) {
		print "$key: $value";
	}
	print "Enter a name: ";
	my $visitor = <STDIN>;
	chomp($visitor);

	if ($is_invited{$visitor}) {
		print "The visitor $visitor is here";
	}
	# The map function is most useful. It transforms a collection of data to a hash.
	# We can do more than one line... 
	# We can change the contents of an array

	my #middleNames = qw /sammy larry bobby jimmy/;
	my @newMiddleNames = map { ucfirst } @middleNames;
	print "@newMiddleNames\n";

	my @firstNames = qw /joe steven robert larry freddie/;
	my @everyone = map {
		uc,
		$_, ucfirst . "'s car"
	} @firstNames;
	print "@everyone\n";

	# Create a hash
#	my %nameHash = ("thomas" =>1,
#					"james" =>
#					"steven" =>
#					"brian" =>
#		)

}
sub option_4e {
	# 
	# 
	my $sentence = “I would like to go to london this year”;
	print “\$sentence before: $sentence”;
	$sentence =~ s/London/London/;
}
sub option_4f {
	# grep seraches for a pattern 
	# Perl can search heterogeneous arrays – of different types 
	my @h_array = (1, “Test”, 55, “foo”, 65, 20);
	my @has_digits = grep /-?\d+(\.\d+)/, #h_array;  # (1, 655, 65, 20)

	print join ", " @has_digits;
}
sub option_4g {
	# use the grep utility to filter out words less than eight characters
	# 
	my @products = qw /potatoes lemons apricots apples banannas pineapple/;
	# Use back slashes / / for string comparisons 
	# Use braces {} when doing a call to a built-in function, i.e. length, count 
	my @small_words = grep { length $_ < 8 } @products
	for my $index (@small_words) {
		print $index;
	}

	my $location = "D:\\TEMP";
	print "Attempting to read location: $location";
	opendir(my $dh, $location) || die ("Cannot opendir $location: $!");

	my @files = readdir("$location") or die ("Cannot read dir: $! at $.");
	print join ", " @files if scalar(@files) > 0;

}
sub option_4h {
    # opendir(my $dh, $some_dir) || die "can't opendir $some_dir: $!";
    # @dots = grep { /^\./ && -f "$some_dir/$_" } readdir($dh);
    # closedir $dh;
	my $location = "D:\\TEMP";
	print "Attempting to read location: $location";
	opendir(my $dh, $location) || die ("Cannot opendir $location: $!");
|	my @files = grep { substr($_, 0, 1) ne "." } readdir($dh);
	my @htmlFiles = grep { /\.html$/ } @files;
	print "The length of the array is: " . scalar(@htmlFiles);
	for my $file (@htmlFiles) {
		print $file;
	}
}
sub option_E {
	print "        E - Extract and process string\n\n";
	print "        Enter a string >";
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	print "                        " . $userInput_1 . " has " . length($userInput_1) . " characters.\n";
}
sub option_P {
	print "        P - Perform a mathematical operation\n\n";
	print "        Enter a mathematical expression for PERL to evaluate >"; 
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	# Ref: http://www.regexlib.com/REDetails.aspx?regexp_id=2970
	my $result = '^ (?: (?> # non backtracking for alternated tokens (?: \- # "-" operator (?=\d|\() # followed by digit or "(" ) | (?: (?<=\d|\)) # preceded by digit or ")" (?:\+|\/|\*) # basic operators except "-" (?=\d|\(|\-) # followed by digit or "(" or "-" ) | (?<parenthesis> # incremente balancing group "parenthesis" counter (?<=^|\+|\/|\-|\*|\() # preceded by start of line or basic operator or "(" \( # opening parenthesis "(" (?=\d|\(|\-) # followed by digit or "-" or "(" ) | (?<-parenthesis> # decrement balancing group "parenthesis" counter (?<=\d|\)) # preceded by digit or ")" \) # opening parenthesis ")" (?!\d) # not followed by digit ) | (?: (?<=\(|\-|\+|\*|\/|^) # preceded by start of line or basic operator or "(" (?:\d+(?:\,\d{1,4})?) # number with optional 4 decimal with comma as decimal marker (?=$|\)|\-|\+|\*|\/) # followed by end of line or ")" or basic operator ) ) + (?(parenthesis)(?!)) # test for balancing group "parenthesis" counter ) # unnamed group whole expression $';
	# ,^ (?: (?> # non backtracking for alternated tokens (?: \- # "-" operator (?=\d|\() # followed by digit or "(" ) | (?: (?<=\d|\)) # preceded by digit or ")" (?:\+|\/|\*) # basic operators except "-" (?=\d|\(|\-) # followed by digit or "(" or "-" ) | (?<parenthesis> # incremente balancing group "parenthesis" counter (?<=^|\+|\/|\-|\*|\() # preceded by start of line or basic operator or "(" \( # opening parenthesis "(" (?=\d|\(|\-) # followed by digit or "-" or "(" ) | (?<-parenthesis> # decrement balancing group "parenthesis" counter (?<=\d|\)) # preceded by digit or ")" \) # opening parenthesis ")" (?!\d) # not followed by digit ) | (?: (?<=\(|\-|\+|\*|\/|^) # preceded by start of line or basic operator or "(" (?:\d+(?:\,\d{1,4})?) # number with optional 4 decimal with comma as decimal marker (?=$|\)|\-|\+|\*|\/) # followed by end of line or ")" or basic operator ) ) + (?(parenthesis)(?!)) # test for balancing group "parenthesis" counter ) # unnamed group whole expression $';
	print "                        " . $userInput_1 . " = " . $result . "\n";
}
sub option_R {
	print "        R - Read a directory of files\n\n";
	print "        Enter a directory's name  >";
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	print "\n";
	system $^O eq 'MSWin32' ? 'dir ' . $userInput_1 : 'pwd ' . $userInput_1;
}
sub option_F {
	print "        F - Find a pattern in a list of files\n\n";
	print "        At what directory? >";
	$dirSearch = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
												# no need to chomp
	print "        Enter a pattern to look for  >";
	$pattern = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
												# no need to chomp
	print "        Resulted matches of pattern among all lines of all files in a directory listed below:\n";
	# Ref: http://stackoverflow.com/questions/1512729
	{
		#my ($fileList) = (system $^O eq 'MSWin32' ? 'dir /w' . $dirSearch : 'ls -l' . $dirSearch);
		#local @ARGV = ($fileList);
		#foreach ($ARGV) {
		#	print "$ARGV:$.:$_" if /Okay/;
		#} continue {
		#	close ARGV if eof;
		#}
	}
}
sub option_L {
	print "        L - Determine if a word is a palindrome\n\n";
	print "        Enter a string >";
	$userInput_1 = trim($userInput_1 = <STDIN>);	# Call subroutine to trim whitespace from input string, 
													# no need to chomp
	# Ref: http://stackoverflow.com/questions/15752965
	if ($userInput_1 ne "") {
		my ($word) = $userInput_1;

		my @chars = split //, $word;
		my $palindrome = 1;
		for (0..@chars/2-1) {
			$palindrome = $chars[$_] eq $chars[-($_+1)]
			or last;
		}
		print "                        $word ".($palindrome ? "is" : "isn't")." a palindrome\n";
	}
}
sub trim {	
	# Trim leading and trailing whitespace with regular expression.
    # (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    return $s;        
	# Can also be done using the String::Util module's trim method.
	# Perl 6 will include a trim function. 
	# Ref: http://stackoverflow.com/questions/4597937
}
# There is no main routine in Perl
$default = '3a';		# global variable
# Invoke subroutine (user-defined function). Ref 1, pg 63
&menu($default);		# pass the default menu choice 'E' in the subroutine's parameter list
