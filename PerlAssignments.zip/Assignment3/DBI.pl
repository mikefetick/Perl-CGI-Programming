#!/usr/bin/perl -wT   # w- warnings, 
                      # T- taint option to protect you when accepting user input
$\ = "\n";

use strict;

#require "cgi-lib.pl";  # deprecated and stay away from this! 
# It is superseded by the CGI module in Perl.
#
#my $email = $_FORM{"email"};
#print "Content-Type: text/html";
#print "Thank you, we will contact you shortly.";
#
use CGI qw(:standard);
# Cart module is helpful
use CGI::Carp qw(warningsToBrowser fatalsToBrowser)

# Use CGI module to call variables
#
# Use a hash called a param hash.
#my $contact_name = param{'contact_name'}
#my $email = param{'email'}
#
# Create a class, consume the class by invoking the method with the arrow
# this is an OOP way to print the header. 
#print $q->header();  # done this way with the CGI  module.
#print $q->start_html;
#print $q->h1("Hello World");
#print $q->end_html;
#
# A resource: www.cgi101.com, get the pdf. 

# Perl module to access the database
use DBI;
use DBI::mysql;  # The provider

# Access mySQL page, create variables

# Connect to the DB with a 'data source name (dsn)':
my $username = "";
my $password = "";
my $database = "";
my $host = "";

# 1. Create the DSN and connect to the database
my $dsn = "dbi:mysql:$database:$host";  # connection string
my $dbh = DBI->connect($dsn, $username, $password) or die("Cannot connect $!");   # Databese handler

# 2. Prepare the query and execute the query
#my $query = "SELECT statename, abbreviation FROM USStates";
my $query = "SELECT statename, population FROM USStates";
#$query .= "FROM USStates";
#my $query = "SELECT * FROM USStates";
my $query_handle = $dbh->prepare($query);
$query_handle->execute();

# 3. Bind the columns to local variables
my $statename;
my $population;
# parameters are to references, not to variables:
$query_handle->bind_columns(undef, \$statename, \$population);

#########################################
sub comify {
	my $text = reverse $_[0];
	$text =~  s/(\d\d\d)(?=\d)(?!\d*\.)/$1,/g;
	return scalar reverse $text;
}
#########################################

my $html = "<table>";

my $row = "";
# While still rows in the record set, do this:
while ($query_handle->fetch()) {
	#$row = "<tr><td>" . $statename . "<tr><td>" . $population . "</tr></td>";
	$row = sprint("<tr><td>%s</td><td class='right'>%s</td></tr>", $statename, comify($population));
	$html .= $row . "\n";
}
$html .= "</table>";

# 4. Close the resources and don't use $dh->close()
$query_handle->$finish(); 
$dbh->disconnect();

# Form variables from the param hash which is differnt that a CGI script:
# The param hash has no sigil % so there no sigi that changes 
# For a web application, use parentheses instead of braces for a hash.  
my $contact_name = param('contact_name');
my $email = param('email');

# Lunarpages
# CGI Param example

# Dump the header
print "Content-type: text/html \n";

# print <<EOT - Created errors so just use the HEREDOC

my $output = << "HERE_DOC";
<html>
<head>
<title>My First CGI Form</title>
<style type="text/css">
.right { text-align: right }
</style>
</head>
<body>


<h2>States of the Union</h2>
$html
</body>
</html>
HERE_DOC
