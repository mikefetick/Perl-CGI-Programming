#!/usr/bin/perl
use strict;
no warnings;	# can use warnings pragma since Perl 5.6 ref 1, pg 28
use Win32::Console;				# On Windows, use the Win32::Console module
$\ = "\n";
my $separator = ("*" x 37);
"""
Assignment #3 - CGI Programming
Due: 03-11-2015 11:55 p.m.

The goal of this assignment is to create two scripts
that will insert data into a database and display 
data.

Create an a CGI script that will process incoming 
form data and insert the data into a MySQL page.
The form can be found here.
You will need to change the form tag attributes to 
process the script.

The first CGI script will take the incoming form 
data and insert it into a MySQL database.  You can 
use PHPMyAdmin to create the table that will 
contain the data.  When you create the table, you 
will need to take into account that two of the form 
elements (sports, and cities) can have multiple 
selections.  Furthermore, the upload file will need 
to be a path to where the file is located at.  You 
can use environmental variables to determine that.

The second CGI script will display all the form 
submissions formatted in a table.  If you wish, you 
can create a link to the second CGI script from 
your first CGI script.


flowers.jpg
cgi-bin physical location: 
e.g. /var/www/html/cgi-bin/flower.jpg


"""

sub menu {
	# As of Perl 5.002, the built-in $^O indicates which operating system is running.
	# Ref: http://stackoverflow.com/questions/4605593
	no strict;   # briefly, turn off
    os.system("MODE 78,86");  # Ref: http://stackoverflow.com/questions/7552644/resize-cmd-window
	use strict;  # immediately, turn on.
	system $^O eq 'MSWin32' ? 'cls' : 'clear';	# Clear screen before showing menu again
	print "";
	print "                         COM330 Perl CGI Programmin \n";
	print "                    Assignment 2 - TV Station Call Letters";
	print "                    -------------------------------------- \n";
	print "    Please enter a station's call letters, i.e. KAAH-TV, KAAL, etc...";
	print "    or a Q to Quit\n";
	print "    The program will display the station information, including the state ";
	print "    it operates in and the number of stations that operate in that state. \n";
    print "  ${separator}${separator} \n";
}


sub get_data_from_file {
	#my $location = 'C:\temp';
	my $location = '.';    # current directory
	my $input_file = '.\CallLetters.txt';
	my @input_array = "";
	my %input_hash = "";
	my $index = '';
	my $value = '';
	# stack the file test to save IO processing
	if (-r -e $input_file) {
		{
			$\ = "";
			open my $input_file_fh, '<', $input_file or die "      Could not open $input_file";
			my @lines = <$input_file_fh>;  # a filehandle read
			close $input_file_fh;
		    #print "                 or press the 'Enter' key to continue... ";
			#print @lines;
			#chomp(my $user_input = <STDIN>);
			foreach my $line (@lines) {
				# Read index into an array
				$index = ($line =~ /^[(A-Z0-9)-]+[\s]/g); 
				$value = split /^[(A-Z0-9)-]+[\s]/, $line; 
				$index = trim($index);
				@input_array[$index] = $value;

				# Read key into a hash
				#my %key = ($line =~ /^[(A-Z0-9)-]+[\s]/g); 
				#my %value = split /^[(A-Z0-9)-]+[\s]/, $line; 
				#%key = trim(%key);
				#%key => %value;
				#unshift @input_array, %key=>%value;

				#chomp(%value);
				#%value = trim(%value);
				#print $line;
				#print %key;
				#print "";
				#-print %value;
				#print "%{value}";
				#print %value;

				# Push key-value pair into array
				#shift @input_array, %key=>%value;
				#push @input_array, %key=>%value;
				#unshift @input_array, %key=>%value;

				#unshift @input_array, %value;
				#shift @input_array, %value;

				#unshift @input_array, %key;
				#shift @input_array, %value;

				#push @input_array, %value;
				#pop @input_array, %value;

				# Push key into array

				#push @input_array, %key;
				#unshift @input_array, %key;
				#push @input_array, %value;
				##shift @input_array, %key;
				#unshift @input_array, %value;

				# Push value into array
				#push @input_array, %value;

				# Extract value and push on array
				#my %value = ($line =~ s/^[(A-Z0-9)-]+[\s]//); 
				#print @input_array;
				#print "";

				#if (%input_hash ne "") {%input_hash = %input_hash.", "}
				#%input_hash = %input_hash."$key"." => "."$value";
			}
			$\ = "\n";
			#print @input_array;
		}
		# Convert array list to hash
		#%input_hash = map { $_, $_ } shift @input_array;
		while(my ($index, $value) = each @input_array) {
		    $input_hash{$value} = $index;
		}

		#print %input_hash;
		#chomp(my $user_input = <STDIN>);

		#while ( (my $key, my $value) = each %input_hash ) {
		#	print($key . " => " . $value);
		#}

		#chomp(my $user_input = <STDIN>);
		return \%input_hash;
	}
	#my $output_file = 'output.txt';
	#opendir(my $dh, $location) || die ("Cannot opendir $location: $!");
	#my @files = grep { substr($_, 0, 1) ne "." } (readdir $dh);
    #closedir $dh;
	#
	#for my $input_file (@files) {
	#	open my $input_file_fh, '<', $input_file or die "      Could not open $input_file";
		#while my $line_read = ($input_file_fh) {
		#	next readline($input_file_fh);
		#}
	#	my $output_file_fh = $input_file_fh;
	#	open my $output_file_fh, '>', $output_file or die "       Could not open $output_file";
	#	open "File:  $input_file\n", '>>:encoding(UTF-8)', &output_file();
	#	close $input_file_fh;
	#	close $input_file_fh;
	#}
}


sub trim {	
	# Trim leading and trailing whitespace with regular expression.
    # (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    (my $s = $_[0]) =~ s/^\s+|\s+$//g;
    return $s;        
	# Can also be done using the String::Util module's trim method.
	# Perl 6 will include a trim function. 
	# Ref: http://stackoverflow.com/questions/4597937
}


sub display_menu {
	# Hash call_letters here works GREAT!
	# but when superseded by the returned converted-hash. It breaks! 
	#  Hard-wired data for test purposes:
	my %call_letters = (
		"KAAH-TV" => "27 PSIP 26 TBN Honolulu, Hawaii K All American TV Honolulu",
		"KAAL" => "36 PSIP 6 6.1ABC 33.2This TV Austin, Minnesota Austin-Albert Lea",
		"KAAS-TV" => "17 PSIP 18 Fox Salina, Kansas Satellite of KSAS-TV Wichita",
	);

	# Data collection - A hash of TV Station Call-Letters, read from file:
	#my %call_letters = &get_data_from_file();
	my $call_letters_ref = &get_data_from_file();
	%call_letters = %$call_letters_ref;

	print %call_letters;

    #print "Dereferenced:\n";
    #foreach my $k (keys %call_letters) {
    #    print "$k: $call_letters{$k}\n";
    #}

	#my $word_count;
	$\ = "";
	#print join ", ", keys %call_letters;

	#foreach my $item (sort keys %call_letters) {
	#	print $item;
	#	print ", ";
	#	${word_count} += 1;
	#	print "\n    " if ${word_count} % 10 == 0;   # ten words per line
	chomp(my $user_input = <STDIN>);
	#}
	$\ = "\n";
	while ( (my $key, my $value) = each %call_letters) {
		print("$key => $value");
	}
	chomp(my $user_input = <STDIN>);

	# Data collection - An array of state names, defined in a statement:
	my @state_names = (
		"Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", 
		"Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", 
		"Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", 
		"Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", 
		"New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", 
		"North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", 
		"South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", 
		"Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming" 
		);
	my $user_input;
	my $call_letters;
	my $key_status = 'looking';
	my $key; 
	my $value;
	my @matching_state;
	my $my_state;
	my $station_count = 0;
	while ($user_input ne 'q') {	# Outer loop while choice is not to Quit. Ref 1, pg 40
		&menu;                # Call subroutine to clear the screen and redraw menu_1
		$\ = "";
	    print "    Please enter a TV station's call letters: ";
		$\ = "\n";
		chomp($user_input = <STDIN>);	# assign STDIN Ref 1, pg 251
		if ($key_status eq 'looking') {
			#while ( ( ($key, $value) = each %call_letters ) ) {
				# Process every record data
				#
				# Best solution - (use mesh) to store a count of TV stations per state,
				# combine two lists: data file and state names (Ref textbook, page 293) 
				# Would have to download module List::MoreUtils from CPAN, then use qw(mesh)
				#
				#my @split_value = split / /, $value; # multiple variables
				#foreach my $item (@split_value) {
				#	@matching_state = grep /\b$item\b/i, @state_names;
				#	print @matching_state;
				#}
				#%my_states_hash = ( (grep /\b$item\b/i, @state_names) => @matching_state + 1 );

			while ( ( ($key, $value) = each %call_letters ) and ( $key_status ne 'found' ) ) {
				if ($key eq uc($user_input)) {
					print "\n      TV Station Info of ".$key.": \n";
					print "      ", $value." \n";
					$key_status = 'found';
					my @state_strcmp = (join "||", @state_names);
					my @split_value = split / /, $value; 
					$\ = "";
					print "      Broadcasting from ";
					foreach my $item (@split_value) {
						@matching_state = grep /\b$item\b/i, @state_names;
						print @matching_state;
					}
					print ", USA ";
				}
			}
			while ( ( ($key, $value) = each %call_letters ) and ( $key_status eq 'found' ) ) {
				$station_count += 1; 
			}
			if ($key_status eq 'found') {
				print "which has ". $station_count . " TV stations broadcasting.";
				$\ = "\n";
				print "\n\n";
			} else {
				print "\n      TV Station Call Letters: $user_input - does not match. \n";
				print "      Maybe it is missplelled, here are all the valid call-letters:";
				$\ = "";
				print "    ";
				my $word_count = 0;
				foreach my $item (sort keys %call_letters) {
					if ($item eq substr($user_input,0,3)) {
						print $item . ", ";
						${word_count} += 1;
						print "\n    " if ${word_count} % 8 == 0;   # ten words per line
					}
				}
				$\ = "\n";
			}
		    print "\n\n  ${separator}${separator} \n";
		    print "           Press the 'q' key, then 'Enter' key to quit the program ";
			$\ = "";
		    print "                 or press the 'Enter' key to continue... ";
			$\ = "\n";
			chomp($user_input = <STDIN>);				# assign STDIN to special variable $_ just once. Ref 1, pg 251
		}
	}
}
sub prompt {
	my $prompt = shift;
	my $reply;
	print $prompt;
}

&display_menu();
