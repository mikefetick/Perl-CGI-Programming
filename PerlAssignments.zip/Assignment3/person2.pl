#!/user/bin/per

package Person;
sub new {
	my $class = shift;
	my $self = {
		_fileName => shift,
		_lastName => shift,
		_gpa => shift,
	};

	print "First Name is $self->{_firstName}";
	print "Last Name is $self->{_lastName}";
	print "GPA is $self->{_gpa}";

	# The bless keyword associates an object with a class
	bless $self, $class;
	return $self;
}
# Create a setter
sub setGPA {
	my ($self, $gpa) = @_;
	$self->{_gpa} = $gpa if defined(gpa);
	return $self->{_gpa};
}

sub getGPA {
	my ($self) = @_;
	return $self->{_gpa};
}
# Recap
"""
1. $%
2. @| is center-justifiy
3. $= is to change the number of rows per package$0 is the script being eexcuted
4. $^L is form feed

5. $~ reset the formatter. The default is STDOUT.
select(STDOUT)
$~ = named formatter of choice











"""
$personInstance = new Person("Joe", "Smith", 3.79);
$personInstance->setGPA(3.88);
print $personInstance->getGPA()
print "The new GPA is ".$personInstance->getGPA()

