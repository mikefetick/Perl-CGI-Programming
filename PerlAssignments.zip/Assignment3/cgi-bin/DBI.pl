#! perl -wT   # w- warnings, 
              # T- taint option to protect you when accepting user input
use strict;
use CGI qw(:standard);    # Use CGI module to call variables
use CGI::Carp qw(warningsToBrowser fatalsToBrowser);

$\ = "\n";
# Use a hash called a param hash.
#my $contact_name = param{'contact_name'}
#my $email = param{'email'}
#
# Create a class, consume the class by invoking the method with the arrow
# this is an OOP way to print the header. 
#print $q->header();  # done this way with the CGI  module.
#print $q->start_html;
#print $q->h1("Hello World");
#print $q->end_html;
#
# A resource: www.cgi101.com, get the pdf. 

# Perl module to access the database
use DBI;
use DBI::mysql;  # The provider

# Access the mySQL page, create variables

# 1. Create the 'data source name' (dsn) 
#    and use a 'database handler' (dbh) to connect to the database
my $database = "colemandevelopment";
my $host = "localhost";            
my $tableName = "perl_assignment3_formdata";
my $username = "sqluser";
my $pwd = "sqluser";
my $dsn = "dbi:mysql:$database:$host";
my $dbh = DBI->connect($dsn, $username, $pwd) or die("Cannot connect $!");   # Databese handler

# 2. Prepare the query and execute the query
#my $query = "SELECT statename, abbreviation FROM USStates";
my $query = "SELECT formdataID, ";
$query .= "firstName, ";
$query .= "lastName, ";
$query .= "address1, ";
$query .= "address2, ";
$query .= "city, ";
$query .= "state, ";
$query .= "email, ";
$query .= "password, ";
$query .= "favColor, ";
$query .= "favSports, ";
$query .= "citiesToVisit ";
$query .= "FROM perl_assignment3_formdata";
my $query_handle = $dbh->prepare($query);
$query_handle->execute();

# 3. Bind the columns to local variables
my $firstName;
my $lastName;
my $address1;
my $address2;
my $city;
my $state;
my $email;
my $password;
my $favColor;
my $favSports;
my $citiesToVisit;
# parameters are to references, not to variables:
$query_handle->bind_columns(undef, \$firstName, \$lastName, 
	\$address1, \$address2, \$city, \$state, \$email, \$password, 
	\$favColor, \$favSports, \$citiesToVisit);

my $html = "<table>";

my $row = "";
# While still rows in the record set, do this:
while ($query_handle->fetch()) {
	$row = "<tr>";
	$row .= "<td>" . $firstName . "</td>";
	$row .= "<td>" . $lastName . "</td>";
	$row .= "<td>" . $address1 . "</td>";
	$row .= "<td>" . $address2 . "</td>";
	$row .= "</tr><tr>";
	$row .= "<td>" . $city . "</td>";
	$row .= "<td>" . $state . "</td>";
	$row .= "<td>" . $email . "</td>";
	$row .= "<td>" . $password . "</td>";
	$row .= "</tr><tr>";
	$row .= "<td>" . $favColor . "</td>";
	$row .= "<td>" . $favSports . "</td>";
	$row .= "<td>" . $citiesToVisit . "</td>";
	$row .= "</tr>";
	$html .= $row . "\n";
}
$html .= "</table>";

# 4. Close the resources and don't use $dh->close()
my $finish; 
$query_handle->$finish(); 
$dbh->disconnect();

# Form variables from the param hash which is different that a CGI script:
# The param hash has no sigil % so there no sigi that changes 
# For a web application, use parentheses instead of braces for a hash.  
#my $contact_name = param('contact_name');
#my $email = param('email');

# Lunarpages
# CGI Param example

# Dump the header
print "Content-type: text/html \n";

my $output = << "HERE_DOC";
<html>
<head>
<title>My First CGI Form</title>
<style type="text/css">
.right { text-align: right }
</style>
</head>
<body>


<h2>States of the Union</h2>
$html
</body>
</html>
HERE_DOC
