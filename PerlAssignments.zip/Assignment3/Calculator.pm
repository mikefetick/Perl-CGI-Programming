package Awesome::Calculator
# The 'Awesome' in 'Awesome::Calculator' will be a directory that must be created.
use strict;
use warnings;

use Exporter qw (import);

# Using 'our' instead of our for scope Perl 5.
# our @EXPORT_OK = qw (add multiply);

# When we ship a package, we want to ship metadata with it.
# this includes version number, etc.
# Include metadata:
use vars qw ($VERSION @ISA @EXPORT_OK %EXPORT_TAGS);
$VERSION 		= 1.00;
@ISA 			= qw (Exporter);  # a special perl array that is a list of parent packages associated with this package

# @EXPORT contains a list of functions that we export *by* default. 
# In this case, it is nothing.
# The less you export, by default, the better.
@EXPORT 		= ();

# @EXPORT_OK contains a list of functions that we export on demand, 
# so we export the three functions *only* if requested to
@EXPORT_OK 		= qw (add multiply divide);

sub add {
	my ($x, $y) = @_;
	return $x + $y;
}

sub multiply {
	my ($x, $y) = @_;
	return $x * $y;
}

sub divide {
	my ($x, $y) = @_;
	return $x / $y;
}



# the last number in the package must be the number one:
1: 