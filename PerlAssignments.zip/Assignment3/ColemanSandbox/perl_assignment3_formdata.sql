-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost:33307
-- Generation Time: Mar 05, 2015 at 08:40 PM
-- Server version: 5.5.42
-- PHP Version: 5.4.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `colemandevelopment`
--

-- --------------------------------------------------------

--
-- Table structure for table `perl_assignment3_formdata`
--

CREATE TABLE IF NOT EXISTS `perl_assignment3_formdata` (
  `formdataID` int(11) NOT NULL,
  `firstName` varchar(32) DEFAULT NULL,
  `lastName` varchar(32) DEFAULT NULL,
  `address1` varchar(32) DEFAULT NULL,
  `address2` varchar(32) DEFAULT NULL,
  `city` varchar(15) DEFAULT NULL,
  `state` varchar(15) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `favColor` varchar(15) DEFAULT NULL,
  `favSports` varchar(45) DEFAULT NULL,
  `citiesToVisit` varchar(100) DEFAULT NULL,
  `filename` varchar(128) DEFAULT NULL,
  `fileBlob` blob
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `perl_assignment3_formdata`
--

INSERT INTO `perl_assignment3_formdata` (`formdataID`, `firstName`, `lastName`, `address1`, `address2`, `city`, `state`, `email`, `password`, `favColor`, `favSports`, `citiesToVisit`, `filename`, `fileBlob`) VALUES
(1, 'fn', 'ln', 'add1', 'add2', 'ci', 'ca', 'en@ys.com', 'asdf', 'red', 'baseball', 'London', 'us-constitution.txt', ''),
(2, 'firstName', 'lastName', 'address1', 'address2', 'city', 'state', 'email', 'password', 'favColor', 'favSports', 'citiesToVisit', 'filename', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `perl_assignment3_formdata`
--
ALTER TABLE `perl_assignment3_formdata`
  ADD PRIMARY KEY (`formdataID`), ADD UNIQUE KEY `formdataID_UNIQUE` (`formdataID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `perl_assignment3_formdata`
--
ALTER TABLE `perl_assignment3_formdata`
  MODIFY `formdataID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
