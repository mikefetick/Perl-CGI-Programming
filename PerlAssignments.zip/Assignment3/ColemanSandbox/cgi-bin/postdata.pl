#!/usr/bin/perl -wT
use CGI qw(:standard);    # Use CGI module to call variables
use CGI::Carp qw(warningsToBrowser fatalsToBrowser);
use Digest::SHA qw(sha256_hex);
use strict;

$\ = "\n";

print header;
print start_html("COM 330 - Assignment #3 - Michael Fetick, 84270");

print '<h3>Contact Information</h3>';
my %form;
my $firstname = ""; 
my $lastname = "";
my $address1 = "";
my $address2 = "";
my $city = "";
my $state = "";
my $email = "";
my $digest = "";
my $color = "";
my $favSportsList = "";
my $citiesList = "";
my $filename = "";
my $filedata = "";

foreach my $p (param()) {
    if ($p eq "firstname") {
        $firstname = param($p);
        print "$p = <u>$firstname</u><br>\n";
    } elsif ($p eq "lastname") {
        $lastname = param($p);
        print "$p = <u>$lastname</u><br>\n";
    } elsif ($p eq "address1") {
        $address1 = param($p);
        print "$p = <u>$address1</u><br>\n";
    } elsif ($p eq "address2") {
        $address2 = param($p);
        print "$p = <u>$address2</u><br>\n";
    } elsif ($p eq "city") {
        $city = param($p);
        print "$p = <u>$city</u><br>\n";
    } elsif ($p eq "state") {
        $state = param($p);
        print "$p = <u>$state</u><br>\n";
    } elsif ($p eq "email") {
        print '<h3>Account Login Information</h3>';
        $email = param($p);
        print "$p = <u>$email</u><br>\n";
    } elsif ($p eq "password") {
        my $plaintext = param($p);
        my $salt  = substr(${plaintext}, 0, 2);
        my $ciphertext = crypt(${plaintext}, ${salt});
        print "Encrypted $p = <u>", $ciphertext ."</u><br>\n";
        $digest = sha256_hex($ciphertext);
        print "SHA256 hashing of encrypted $p = <u>", $digest, "</u><br>\n";
        $p = $digest;
        print '<h3>Favorite Choices</h3>';
    } elsif ($p eq "colors") {
        $color = param($p);
	        print "You picked your favorite color: <u>$color</u><br>\n";
    } elsif ($p eq "favoritesport") {
	    my @sports = param($p);
	    my $i = 0;
	    my $favSportsCount = @sports;
	    foreach my $sport (@sports) {
            if ($i < 1) {
                $favSportsList = $sport;
            } else {
                $favSportsList .= ', '. $sport;
            }
            $i++;
        }
        $favSportsList =~ (s/,([^,]*),?$/ and $1/g);
        print "You picked $favSportsCount of your favorite sports: <u>$favSportsList</u>.<br>\n";
    } elsif ($p eq "citiesToVisit") {
	    my @cities = param($p);
	    my $i = 0;
	    my $citiesCount = @cities;
	    foreach my $city (@cities) {
            if ($i < 1) {
                $citiesList = $city;
            } else {
                $citiesList .= ', '. $city;
            }
            $i++;
        }
        $citiesList =~ (s/,([^,]*),?$/ and $1/g);
        if ($citiesCount == 1) {
	        print "You picked $citiesCount city to visit: <u>$citiesList</u>.<br>\n";
        } else {
	        print "You picked $citiesCount cities to visit: <u>$citiesList</u>.<br>\n";
        }
    } elsif ($p eq "filename") {
        my $filename = param($p);
        print "Your filename = <u>$filename</u><br>\n";
        if ($filename) {
            #$filedata = do {
            #    local $/;
            #    open my $tarfile, '<:raw', "$filename"
            #      or die $!;  # this particular line not that cosmetic...
            #    <$tarfile>
            #    close $tarfile;
            #}
            #Commented-out the blob because it makes the program stop for a long time.
            print "Your file blob (truncated) = <u>\". substr($filedata, 0, 256)" . "</u>";
        } else {
            print "Your file blob (truncated) = ";
        }
    } else {
	    $form{$p} = param($p);
        print "$p = <u>$form{$p}</u><br>\n";
    }
}
my $sqlString_Input = "INSERT INTO `perl_assignment3_formdata`(";
$sqlString_Input .= "`firstName`, `lastName`, `address1`, `address2`, `city`, `state`, ";
$sqlString_Input .= "`email`, `password`, `favColor`, `favSports`, `citiesToVisit`, `filename`) ";
$sqlString_Input .= "VALUES (('${firstname}'), ('${lastname}'), ('${address1}'), ('${address2}'), ('${city}'), ('${state}'),";
$sqlString_Input .= "('${email}'), ('${digest}'), ('${color}'), ('${favSportsList}'), ('${citiesList}'), ('${filename}'), ('${filedata}'))";

my $imageFile = './leader.gif';
print '<div id="head"><h4 id="image"><i><img src="'.$imageFile.'" alt="Image: Salvation for Dummies" width="140" height="85" /></i></h4></div>';
print '<form action="/cgi-bin/bindings.pl" method="POST">';
print '  <div>';
print "    <input id=\"sqlString_Input\" name=\"sqlString_Input\" type=\"hidden\" value=\"$sqlString_Input\" placeholder=\"sqlString_Input\">";
print '    <h3>To save your record into the database, press: <button type="submit">Save</button></h3>';
print '  </div>';
print '</form>';
print end_html;