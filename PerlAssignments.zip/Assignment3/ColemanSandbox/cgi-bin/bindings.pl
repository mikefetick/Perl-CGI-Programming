#!/usr/bin/perl -wT
use CGI qw(:standard);    # Use CGI module to call variables
use CGI::Carp qw(warningsToBrowser fatalsToBrowser);
use DBI;         # Perl module to access the database
use DBI::mysql;  # The provider
use strict;

$\ = "\n";
# Use a hash called a param hash.
#my $contact_name = param{'contact_name'}
#my $email = param{'email'}
#
# Create a class, consume the class by invoking the method with the arrow
# this is an OOP way to print the header. 
#print $q->header();  # done this way with the CGI  module.
#print $q->start_html;
#print $q->h1("Hello World");
#print $q->end_html;
#
# A resource: www.cgi101.com, get the pdf. 
my $html = '';
$html .= "<table border=\"1\" style=\"border-collapse:collapse;\">";
$html .= '<caption><h2>Assignment 3 - Database Accessed</h2></caption><colgroup><col span="6" /></colgroup>';

my $row = "";
$row .= "<tr><i>";
$row .= '<td width="100">First Name</td>';
$row .= '<td width="100">Last Name</td>';
$row .= '<td width="150">Address Line 1</td>';
$row .= '<td width="100">Address Line 2</td>';
$row .= '<td width="100">City</td>';
$row .= '<td width="100">State</td>';
$row .= "</tr>\n<tr>";
$row .= '<td width="200" colspan="2">E-mail</td>';
$row .= '<td width="450" colspan="4">Password</td>';
$row .= "</tr>\n<tr>";
$row .= '<td width="100" colspan="1">Favorite Color</td>';
$row .= '<td width="250" colspan="2">Favorite Sports</td>';
$row .= '<td width="300" colspan="3">Cities To Visit</td>';
$row .= "</tr>\n<tr>";
$row .= '<td width="650" colspan="6">Filename</td>';
$row .= "</i></tr>\n<tr>";
$row .= '<td width="650" colspan="6" align="center"><h4><i>Data shown is fictitous for test purposes and not related to any real information.</i></h4></td>';
$row .= "</tr>";
$html .= $row;
$html .= '</table><br>';

# Access the mySQL page, create variables

# 1. Create the 'data source name' (dsn) 
#    and use a 'database handler' (dbh) to connect to the database
# database for production
my $database = "ad84270";    
my $username = "ad84270";
my $pwd = "5050c748";
# database for development
#my $database = "colemandevelopment";    
#my $username = "sqluser";
#my $pwd = "sqluser";
my $host = "localhost";            
my $tableName = "perl_assignment3_formdata";
my $dsn = "dbi:mysql:$database:$host";
my $dbh = DBI->connect($dsn, $username, $pwd) or die("Cannot connect $!");   # Databese handler

# 2. Prepare the query and execute the query
my $query;
# 2a. Build an INSERT sql query string from this parameter:
$query = param('sqlString_Input');
#$html .= $query;
$dbh->{AutoCommit} = 1; # enable auto-commit
#$dbh->{AutoCommit} = 0; # disable auto-commit
$dbh->rollback;  # no point in holding locks that you aren't using
my $query_handle = $dbh->prepare($query);
#$query_handle->execute();
#$query_handle->commit() or die $dbh->errstr;
#Can't locate object method "commit" via package "DBI::st" 

# 2b. Build a SELECT sql query string from this parameter:
# IMPORTANT: Do not include the PK because it is undef and will break the while loop
$query = "SELECT ";
$query .= "firstName, ";
$query .= "lastName, ";
$query .= "address1, ";
$query .= "address2, ";
$query .= "city, ";
$query .= "state, ";
$query .= "email, ";
$query .= "password, ";
$query .= "favColor, ";
$query .= "favSports, ";
$query .= "citiesToVisit, ";
$query .= "filename ";
$query .= "FROM `colemandevelopment`.`perl_assignment3_formdata`";
# This works too! - $query2 can substitute $query and is another way to build the query string (2 lines)
#my $query2 = qq(select firstName,lastName,address1,address2,city,state,email,password,favColor,favSports,citiesToVisit,filename from colemandevelopment.perl_assignment3_formdata);
#my $query_handle = $dbh->prepare($query2);
my $query_handle = $dbh->prepare($query);
$query_handle->execute();

# 3. Bind the columns to local variables. These parameters are \references, not variables:
# Ref: http://docstore.mik.ua/orelly/linux/dbi/ch05_04.htm
# IMPORTANT: Do not include the PK ($studentID) because it is undef and will break the while loop
my ($firstName, $lastName, $address1, $address2, $city, $state,
	$email, $password, $favColor, $favSports, $citiesToVisit, $filename);
$query_handle->bind_columns(
	\$firstName, 
	\$lastName, 
	\$address1, 
	\$address2, 
	\$city, 
	\$state, 
	\$email, 
	\$password, 
	\$favColor, 
	\$favSports, 
	\$citiesToVisit,
	\$filename
	);

# Test output (13 lines)
#$studentID = 'test';
#...

# Two ways, I couldn't get to work (7 lines)
#my @array;
#while ( my $ref = $query_handle->fetchrow_arrayref() ) {
#	push @array,[@$ref];
#}
#while ( my @arr = $query_handle->fetchrow_array() ) {
#	push @array,\@arr;
#}

# To get the number of columns:
#my $count;
#foreach (@array) {
#	$count = @{ $_ };    
#}

# Another table and do-while there are still rows in the record set:
$html .= "<table border=\"1\" style=\"border-collapse:collapse;\">";
$html .= '<colgroup><col span="6" /></colgroup>';
$row = "";

# Test output (16 lines)
#$row .= '<tr>';
#$row .= '<td width="100">'."$firstName</td>";
#...

# Build and fill each row, with alternating row shading
use vars qw($greyRow $whiteRow $rowColor); # Global variables
$greyRow = "#C0C0C0";
$whiteRow = "#FFFFFF";
my $i = 0;
while ($query_handle->fetchrow_arrayref) {
	$i++;
	# test-expression ? if-true-expression : if-false-expression
	our $rowColor = ($i % 2 == 0) ? (our $grewRow) : (our $whiteRow);
	$row .= '<tr bgcolor="(' . $rowColor . ")\">";
	$row .= '<td width="100">'.$firstName.'</td>';
	$row .= '<td width="100">'.$lastName.'</td>';
	$row .= '<td width="150">'.$address1.'</td>';
	$row .= '<td width="100">'.$address2.'</td>';
	$row .= '<td width="100">'.$city.'</td>';
	$row .= '<td width="100">'.$state.'</td>';
	$row .= "</tr>\n";
	$row .= '<tr bgcolor="(' . $rowColor . ")\">";
	$row .= '<td width="200" colspan="2">'.$email.'</td>';
	$row .= '<td width="450" colspan="4">'.$password.'</td>';
	$row .= "</tr>\n";
	$row .= '<tr bgcolor="(' . $rowColor . ")\">";
	$row .= '<td width="100" colspan="1">'.$favColor.'</td>';
	$row .= '<td width="250" colspan="2">'.$favSports.'</td>';
	$row .= '<td width="300" colspan="3">'.$citiesToVisit.'</td>';
	$row .= "</tr>\n";
	$row .= '<tr bgcolor="(' . $rowColor . ")\">";
	$row .= '<td width="650" colspan="6">filename</td>';
	$row .= "</tr>\n";
}
$row .= "<tr>\n";
$row .= '<td width="650" colspan="6" align="center"><h4><i>Data shown is fictitous for test purposes and not related to any real information.</i></h4></td>';
$row .= "</tr>";
$html .= $row;
$html .= '</table>';

# 4. Close the resources and don't use $dh->close()
$query_handle->finish(); 
$dbh->disconnect();

# Form variables from the param hash which is different that a CGI script:
# The param hash has no sigil % so there no sigi that changes 
# For a web application, use parentheses instead of braces for a hash.  
#my $contact_name = param('contact_name');
#my $email = param('email');

# Lunarpages
# CGI Param example

# Dump the header 
#<style type="text/css" .right { text-align: right }></style>

print "Content-type: text/html \n";

my $output = << "HERE_DOC";
<html>
<head>
<title>COM 330 - Assignment 3 - Michael Fetick, 84270</title>
</head>
<body>
$html
</body>
</html>
HERE_DOC

print $output;
