#!usr/bin/perl

use Awesome::Calculator qw (add);

print add(5, 5);

# D:\Development\Coleman\COM330
# first check to see if the Perl script will compile: perl -c ...
# In Windows, Control Panel, System-Security, Advanced System Settings, path
# @INC the inc array is Perl's path.
# perl -e for execute
# perl -e "print qq(@INC)"
# The 'Awesome' in 'Awesome::Calculator' will be a directory that must be created.
# When we ship a package, we want to ship metadata with it.
# this includes version number, etc.
# Include metadata:
